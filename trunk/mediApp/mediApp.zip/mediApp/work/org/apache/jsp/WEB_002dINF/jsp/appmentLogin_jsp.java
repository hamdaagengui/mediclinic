package org.apache.jsp.WEB_002dINF.jsp;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import com.mediapp.domain.common.Person;

public final class appmentLogin_jsp extends org.apache.jasper.runtime.HttpJspBase
    implements org.apache.jasper.runtime.JspSourceDependent {

  private static final JspFactory _jspxFactory = JspFactory.getDefaultFactory();

  private static java.util.List _jspx_dependants;

  static {
    _jspx_dependants = new java.util.ArrayList(3);
    _jspx_dependants.add("/WEB-INF/jsp/welcomeInclude.jsp");
    _jspx_dependants.add("/WEB-INF/jsp/footer.jsp");
    _jspx_dependants.add("/WEB-INF/tld/verticalMenuItemTag.tld");
  }

  private org.apache.jasper.runtime.TagHandlerPool _005fjspx_005ftagPool_005fspring_005fbind_0026_005fpath;
  private org.apache.jasper.runtime.TagHandlerPool _005fjspx_005ftagPool_005fc_005fout_0026_005fvalue_005fnobody;

  private javax.el.ExpressionFactory _el_expressionfactory;
  private org.apache.AnnotationProcessor _jsp_annotationprocessor;

  public Object getDependants() {
    return _jspx_dependants;
  }

  public void _jspInit() {
    _005fjspx_005ftagPool_005fspring_005fbind_0026_005fpath = org.apache.jasper.runtime.TagHandlerPool.getTagHandlerPool(getServletConfig());
    _005fjspx_005ftagPool_005fc_005fout_0026_005fvalue_005fnobody = org.apache.jasper.runtime.TagHandlerPool.getTagHandlerPool(getServletConfig());
    _el_expressionfactory = _jspxFactory.getJspApplicationContext(getServletConfig().getServletContext()).getExpressionFactory();
    _jsp_annotationprocessor = (org.apache.AnnotationProcessor) getServletConfig().getServletContext().getAttribute(org.apache.AnnotationProcessor.class.getName());
  }

  public void _jspDestroy() {
    _005fjspx_005ftagPool_005fspring_005fbind_0026_005fpath.release();
    _005fjspx_005ftagPool_005fc_005fout_0026_005fvalue_005fnobody.release();
  }

  public void _jspService(HttpServletRequest request, HttpServletResponse response)
        throws java.io.IOException, ServletException {

    PageContext pageContext = null;
    HttpSession session = null;
    ServletContext application = null;
    ServletConfig config = null;
    JspWriter out = null;
    Object page = this;
    JspWriter _jspx_out = null;
    PageContext _jspx_page_context = null;


    try {
      response.setContentType("text/html");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			null, true, 8192, true);
      _jspx_page_context = pageContext;
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      session = pageContext.getSession();
      out = pageContext.getOut();
      _jspx_out = out;

      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("    \r\n");
      out.write("    \r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("<html>\r\n");
      out.write("<head> \r\n");
      out.write("    <title>AppMent</title>    \r\n");
      out.write("\t<link rel=\"shortcut icon\" href=\"");
      out.print(request.getContextPath());
      out.write("/images/shakehand.ico\" type=\"image/x-icon\" />\r\n");
      out.write("\t<link rel=\"stylesheet\" href=\"");
      out.print(request.getContextPath());
      out.write("/css/jquery-ui.css\" type=\"text/css\" />\r\n");
      out.write("    <link href=\"");
      out.print(request.getContextPath());
      out.write("/css/mycss.css\" rel=\"stylesheet\" type=\"text/css\">\r\n");
      out.write("    <link rel=\"stylesheet\" href=\"");
      out.print(request.getContextPath());
      out.write("/css/openid.css\" />    \r\n");
      out.write("    <script type=\"text/javascript\"  src=\"");
      out.print(request.getContextPath());
      out.write("/js/jquery.min.js\"></script>\r\n");
      out.write("    <script type=\"text/javascript\"  src=\"");
      out.print(request.getContextPath());
      out.write("/js/jquery-ui.min.js\"></script>\r\n");
      out.write("\t<script type=\"text/javascript\" src=\"");
      out.print(request.getContextPath());
      out.write("/js/customalert.js\"></script>\r\n");
      out.write("\r\n");
      out.write("</head>\r\n");
      out.write("<body onLoad=\"initVar(); moveBanner()\">\r\n");
      out.write("\t<div id=\"main\" >\r\n");
      out.write("\t\t<div id=\"header\">\r\n");
      out.write("\t\t\t<div id=\"name\" > \r\n");
      out.write("\t\t\t\t<h3> AppMent \r\n");
      out.write("\t\t\t\t</h3>\r\n");
      out.write("\t\t\t\t<h4> <font color=\"grey\">Easy way to get organized!</font> \r\n");
      out.write("\t\t\t\t</h4>\r\n");
      out.write("\t\t\t</div>\r\n");
      out.write("\t\t\t<div id=\"controls\">\r\n");
      out.write("\t\t\t\t\t<form id=\"searchform\" action=\"");
      out.print(request.getContextPath());
      out.write("\" method=\"post\">\r\n");
      out.write("\t\t\t\t\t<a href=\"http://www.facebook.com/apps/application.php?id=152456314791817&v=info\" TARGET=\"_blank\">\r\n");
      out.write("\t\t\t\t\t<img src=\"/images/Facebook-Buttons-11-2.png\" title=\"Find us on Facebook\"  \r\n");
      out.write("\t\t\t\t\talt=\"Find us on Facebook\" width=\"21px\" border=\"0\"/></a><br/>\r\n");
      out.write("\t\t\t\t        ");
Person p = (Person)request.getSession().getAttribute("person");
				        	if (p != null) {
      out.write("\r\n");
      out.write("\t\t\t\t\t\t        <a href=\"logOut.htm\" >Logout</a>\r\n");
      out.write("\t\t\t\t\t\t        \r\n");
      out.write("\t\t\t\t        ");
} 
      out.write("\r\n");
      out.write("\t\t\t\t\t</form>\r\n");
      out.write("\t\t\t</div>\r\n");
      out.write("\t\t</div>\r\n");
      out.write("<div >\r\n");
      out.write("\t\t\t\t\t\t\t\r\n");
      out.write("\t\t\t\t\t\t\t\t<div align=\"right\">\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\r\n");
      out.write("\t\t\t\t\t\t\t\t");

									if (p != null){
										out.print("Welcome " + p.getUsername());
									}
								
      out.write("\r\n");
      out.write("\t\t\t\t\t\t\t\t\r\n");
      out.write("\t\t\t\t\t\t\t\t</div>\r\n");
      out.write("</div>\r\n");
      out.write("\t\t<div id=\"contentHeadLeft\">\r\n");
      out.write("\t\t\t<div id=\"contentHeadRight\">\r\n");
      out.write("\t\t\t\t\r\n");
      out.write("\t\t\t\t<div id=\"contentHeadCenter\">\r\n");
      out.write("\t\t\t\t</div>\r\n");
      out.write("\t\t\t</div>\t\t\r\n");
      out.write("\t\t</div>\r\n");
      out.write("<script type=\"text/javascript\">\r\n");
      out.write("//hide('Menu1');\r\n");
      out.write("//hide('Menu2');\r\n");
      out.write("\r\n");
      out.write("</script>\r\n");
      out.write("<div id=\"helpbox\"></div>");
      out.write("\r\n");
      out.write("\t\t<div id=\"contentBodyLeft\">\r\n");
      out.write("\t\t\t<div id=\"contentBodyRight\">\r\n");
      out.write("\t\t\t\t<div id=\"contentBodyCenter\">\r\n");
      out.write("\t\t\t\t\t<div class=\"stp\" style=\"margin-bottom:1.5em;\">\r\n");
      out.write("\t\t\t\t\t\t<div class=\"or\" style=\"margin:1em; padding:0;\" >\t\t\t\t\t\t\t\t\r\n");
      out.write("\t\t\t\t\t<div id=\"contentSingleEntry\" style=\"\">\r\n");
      out.write("\t\t\t\t\t\t<div id=\"entries\" align=\"left\">\r\n");
      out.write("<script>\r\n");
      out.write("var cacheonimg = new Image ();\r\n");
      out.write("var cacheoffimg = new Image ();\r\n");
      out.write("cacheonimg.src = '/images/MCbutton_1.png';\r\n");
      out.write("cacheoffimg.src = '/images/MCbutton_0.png';\r\n");
      out.write("\r\n");
      out.write("var cacheonimgl = new Image ();\r\n");
      out.write("var cacheoffimgl = new Image ();\r\n");
      out.write("cacheonimgl.src = '/images/MLbutton_1.png';\r\n");
      out.write("cacheoffimgl.src = '/images/MLbutton_0.png';\r\n");
      out.write("\r\n");
      out.write("var cacheonimgs = new Image ();\r\n");
      out.write("var cacheoffimgs = new Image ();\r\n");
      out.write("cacheonimgs.src = '/images/submitbutton_1.png';\r\n");
      out.write("cacheoffimgs.src = '/images/submitbutton_0.png';\r\n");
      out.write("\r\n");
      out.write("</script>\r\n");
      out.write("\t\t\t\t\t\t\r\n");
      out.write("\t\t\t\t\t\t\t<div class=\"entryAlone\" >\r\n");
      out.write("\t\t\t\t\t\t\t<table>\r\n");
      out.write("\t\t\t\t\t\t\t<tr>\r\n");
      out.write("\t\t\t\t\t\t\t\t<td width=\"65%\">\r\n");
      out.write("\t\t\t\t\t\t\t\t<table  border=\"0\"    align=\"left\">  \r\n");
      out.write("\t\t\t\t\t\t\t\t\t\t  <tr>\r\n");
      out.write("\t\t\t\t\t\t\t\t\t\t  \t\t<td>\r\n");
      out.write("\t\t\t\t\t\t\t\t\t\t\t\t\t<form action=\"j_spring_openid_security_check\" method=\"post\" id=\"openid_form\">\r\n");
      out.write("\t\t\t\t\t\t\t\t\t\t\t\t\t\t<input type=\"hidden\" name=\"action\" value=\"verify\" />\r\n");
      out.write("\t\t\t\t\t\t\t\t\t\t\t\t\t \r\n");
      out.write("\t\t\t\t\t\t\t\t\t\t\t\t\t\t<fieldset>\r\n");
      out.write("\t\t\t\t\t\t\t\t\t\t\t\t\t    \t\t<legend>Sign-in with if you already have any of these ID</legend>\r\n");
      out.write("\t\t\t\t\t\t\t\t\t\t\t\t\t    \t\t\r\n");
      out.write("\t\t\t\t\t\t\t\t\t\t\t\t\t    \t\t<div id=\"openid_choice\">\r\n");
      out.write("\t\t\t\t\t\t\t\t\t\t\t\t\t\t    \t\t<p>Please click your account provider:</p>\r\n");
      out.write("\t\t\t\t\t\t\t\t\t\t\t\t\t\t    \t\t<div id=\"openid_btns\"></div>\r\n");
      out.write("\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</div>\r\n");
      out.write("\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\r\n");
      out.write("\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<div id=\"openid_input_area\">\r\n");
      out.write("\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<input id=\"openid_identifier\" name=\"openid_identifier\" type=\"text\" value=\"http://\" />\r\n");
      out.write("\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<input id=\"openid_submit\" type=\"submit\" value=\"Sign-In\"/>\r\n");
      out.write("\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</div>\r\n");
      out.write("\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<noscript>\r\n");
      out.write("\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<p>OpenID is service that allows you to log-on to many different websites using a single indentity.\r\n");
      out.write("\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\tFind out <a href=\"http://openid.net/what/\">more about OpenID</a> and <a href=\"http://openid.net/get/\">how to get an OpenID enabled account</a>.</p>\r\n");
      out.write("\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</noscript>\r\n");
      out.write("\t\t\t\t\t\t\t\t\t\t\t\t\t\t</fieldset>\r\n");
      out.write("\t\t\t\t\t\t\t\t\t\t\t\t\t</form>\r\n");
      out.write("\t\t\t\t\t\t\t\t\t\t\t\t</td>\t\t\t\t\t\t\t\t\t\t  \r\n");
      out.write("\t\t\t\t\t\t\t\t\t\t  </tr>\r\n");
      out.write("\t\t\t\t\t\t\t\t\t\t\r\n");
      out.write("\t\t\t\t\t\t\t\t</table>\t\t\t\t\t\t\t\t\t\t\t\t\t\r\n");
      out.write("\t\t\t\t\t\t\t\t\r\n");
      out.write("\t\t\t\t\t\t\t\t</td>\r\n");
      out.write("\t\t\t\t\t\t\t</tr>\r\n");
      out.write("\t\t\t\t\t\t\t</table>\r\n");
      out.write("\t\t\t\t\t\t\t</div> \r\n");
      out.write("\t\t\t\t\t\t</div>\r\n");
      out.write("\t\t\t\t\t\t<div id=\"column\" >\r\n");
      out.write("\t\t\t\t\t\t\t<form name=\"appMentlogin\" id=\"appMentlogin\" method=\"post\"> \r\n");
      out.write("\t\t\t\t\t\t\t<div class=\"stp\" style=\"margin-bottom:1.em;\">\r\n");
      out.write("\t  \t\t\t\t\t\t\t<div class=\"or\" style=\"margin:1em; padding:0;\">\t  \t\t\t\t\t\t\t \r\n");
      out.write("\t  \t\t\t\t\t\t\t\t<span style=\"font-size:2.0em;font-color:black;font:Verdana\">  Login</span>\r\n");
      out.write("\t  \t\t\t\t\t\t\t\t<br> <br> \r\n");
      out.write("\t\t\t\t\t\t\t\t\t<table class=\"sample\" width=\"100%\" >  \r\n");
      out.write("\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\r\n");
      out.write("\t\t\t\t\t\t\t\t\t\t<tr >\r\n");
      out.write("\t\t\t\t\t\t\t\t\t\t\t<td  align=\"right\" >Name: </td>\r\n");
      out.write("\t\t\t\t\t\t\t\t\t\t\t<td align=\"left\">\r\n");
      out.write("\t\t\t\t\t\t\t\t\t\t\t\t");
      //  spring:bind
      org.springframework.web.servlet.tags.BindTag _jspx_th_spring_005fbind_005f0 = (org.springframework.web.servlet.tags.BindTag) _005fjspx_005ftagPool_005fspring_005fbind_0026_005fpath.get(org.springframework.web.servlet.tags.BindTag.class);
      _jspx_th_spring_005fbind_005f0.setPageContext(_jspx_page_context);
      _jspx_th_spring_005fbind_005f0.setParent(null);
      // /WEB-INF/jsp/appmentLogin.jsp(76,12) name = path type = null reqTime = true required = true fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
      _jspx_th_spring_005fbind_005f0.setPath("person.username");
      int[] _jspx_push_body_count_spring_005fbind_005f0 = new int[] { 0 };
      try {
        int _jspx_eval_spring_005fbind_005f0 = _jspx_th_spring_005fbind_005f0.doStartTag();
        if (_jspx_eval_spring_005fbind_005f0 != javax.servlet.jsp.tagext.Tag.SKIP_BODY) {
          org.springframework.web.servlet.support.BindStatus status = null;
          status = (org.springframework.web.servlet.support.BindStatus) _jspx_page_context.findAttribute("status");
          do {
            out.write("\r\n");
            out.write("\t\t\t\t\t\t\t\t\t\t\t\t\t<input type=\"text\" name=\"username\"  id=\"username\"  value=\"");
            if (_jspx_meth_c_005fout_005f0(_jspx_th_spring_005fbind_005f0, _jspx_page_context, _jspx_push_body_count_spring_005fbind_005f0))
              return;
            out.write("\" size=\"10\" tabindex=\"1\" />\t\t\r\n");
            out.write("\t\t\t\t\t\t\t\t\t\t\t\t\t<script>document.getElementById('username').focus()</script>\r\n");
            out.write("\r\n");
            out.write("\t\t\t\t\t\t\t\t\t\t\t\t");
            int evalDoAfterBody = _jspx_th_spring_005fbind_005f0.doAfterBody();
            status = (org.springframework.web.servlet.support.BindStatus) _jspx_page_context.findAttribute("status");
            if (evalDoAfterBody != javax.servlet.jsp.tagext.BodyTag.EVAL_BODY_AGAIN)
              break;
          } while (true);
        }
        if (_jspx_th_spring_005fbind_005f0.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE) {
          return;
        }
      } catch (Throwable _jspx_exception) {
        while (_jspx_push_body_count_spring_005fbind_005f0[0]-- > 0)
          out = _jspx_page_context.popBody();
        _jspx_th_spring_005fbind_005f0.doCatch(_jspx_exception);
      } finally {
        _jspx_th_spring_005fbind_005f0.doFinally();
        _005fjspx_005ftagPool_005fspring_005fbind_0026_005fpath.reuse(_jspx_th_spring_005fbind_005f0);
      }
      out.write("\r\n");
      out.write("\t\t\t\t\t\t\t\t\t\t\t</td>\r\n");
      out.write("\r\n");
      out.write("\t\t\t\t\t\t\t\t\t\t</tr> \r\n");
      out.write("\t\t\t\t\t\t\t\t\t\t<tr></tr>\r\n");
      out.write("\t\t\t\t\t\t\t\t\t\t<tr>\r\n");
      out.write("\t\t\t\t\t\t\t\t\t\t\t<td colspan=\"2\" align=\"center\">\r\n");
      out.write("\t\t\t\t\t\t\t\t\t\t\t\t");
      //  spring:bind
      org.springframework.web.servlet.tags.BindTag _jspx_th_spring_005fbind_005f1 = (org.springframework.web.servlet.tags.BindTag) _005fjspx_005ftagPool_005fspring_005fbind_0026_005fpath.get(org.springframework.web.servlet.tags.BindTag.class);
      _jspx_th_spring_005fbind_005f1.setPageContext(_jspx_page_context);
      _jspx_th_spring_005fbind_005f1.setParent(null);
      // /WEB-INF/jsp/appmentLogin.jsp(87,12) name = path type = null reqTime = true required = true fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
      _jspx_th_spring_005fbind_005f1.setPath("person.username");
      int[] _jspx_push_body_count_spring_005fbind_005f1 = new int[] { 0 };
      try {
        int _jspx_eval_spring_005fbind_005f1 = _jspx_th_spring_005fbind_005f1.doStartTag();
        if (_jspx_eval_spring_005fbind_005f1 != javax.servlet.jsp.tagext.Tag.SKIP_BODY) {
          org.springframework.web.servlet.support.BindStatus status = null;
          status = (org.springframework.web.servlet.support.BindStatus) _jspx_page_context.findAttribute("status");
          do {
            out.write("\r\n");
            out.write("\t\t\t\t\t\t\t\t\t\t\t\t\t\t<font color=\"red\">");
            if (_jspx_meth_c_005fout_005f1(_jspx_th_spring_005fbind_005f1, _jspx_page_context, _jspx_push_body_count_spring_005fbind_005f1))
              return;
            out.write("</font>\r\n");
            out.write("\t\t\t\t\t\t\t\t\t\t\t\t");
            int evalDoAfterBody = _jspx_th_spring_005fbind_005f1.doAfterBody();
            status = (org.springframework.web.servlet.support.BindStatus) _jspx_page_context.findAttribute("status");
            if (evalDoAfterBody != javax.servlet.jsp.tagext.BodyTag.EVAL_BODY_AGAIN)
              break;
          } while (true);
        }
        if (_jspx_th_spring_005fbind_005f1.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE) {
          return;
        }
      } catch (Throwable _jspx_exception) {
        while (_jspx_push_body_count_spring_005fbind_005f1[0]-- > 0)
          out = _jspx_page_context.popBody();
        _jspx_th_spring_005fbind_005f1.doCatch(_jspx_exception);
      } finally {
        _jspx_th_spring_005fbind_005f1.doFinally();
        _005fjspx_005ftagPool_005fspring_005fbind_0026_005fpath.reuse(_jspx_th_spring_005fbind_005f1);
      }
      out.write("\r\n");
      out.write("\t\t\t\t\t\t\t\t\t\t\t</td>\r\n");
      out.write("\t\t\t\t\t\t\t\t\t\t</tr>\r\n");
      out.write("\r\n");
      out.write("\t\t\t\t\t\t\t\t\t\t<tr>\r\n");
      out.write("\t\t\t\t\t\t\t\t\t\t\t<td  align=\"right\" >Key: </td>\r\n");
      out.write("\t\t\t\t\t\t\t\t\t\t\t<td  align=\"left\">\r\n");
      out.write("\t\t\t\t\t\t\t\t\t\t\t\t");
      //  spring:bind
      org.springframework.web.servlet.tags.BindTag _jspx_th_spring_005fbind_005f2 = (org.springframework.web.servlet.tags.BindTag) _005fjspx_005ftagPool_005fspring_005fbind_0026_005fpath.get(org.springframework.web.servlet.tags.BindTag.class);
      _jspx_th_spring_005fbind_005f2.setPageContext(_jspx_page_context);
      _jspx_th_spring_005fbind_005f2.setParent(null);
      // /WEB-INF/jsp/appmentLogin.jsp(96,12) name = path type = null reqTime = true required = true fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
      _jspx_th_spring_005fbind_005f2.setPath("person.password");
      int[] _jspx_push_body_count_spring_005fbind_005f2 = new int[] { 0 };
      try {
        int _jspx_eval_spring_005fbind_005f2 = _jspx_th_spring_005fbind_005f2.doStartTag();
        if (_jspx_eval_spring_005fbind_005f2 != javax.servlet.jsp.tagext.Tag.SKIP_BODY) {
          org.springframework.web.servlet.support.BindStatus status = null;
          status = (org.springframework.web.servlet.support.BindStatus) _jspx_page_context.findAttribute("status");
          do {
            out.write("\r\n");
            out.write("\t\t\t\t\t\t\t\t\t\t\t\t\t<input type=\"password\" name=\"password\" id=\"password\" tabindex=\"2\" size=\"10\" />\r\n");
            out.write("\t\t\t\t\t\t\t\t\t\t\t\t");
            int evalDoAfterBody = _jspx_th_spring_005fbind_005f2.doAfterBody();
            status = (org.springframework.web.servlet.support.BindStatus) _jspx_page_context.findAttribute("status");
            if (evalDoAfterBody != javax.servlet.jsp.tagext.BodyTag.EVAL_BODY_AGAIN)
              break;
          } while (true);
        }
        if (_jspx_th_spring_005fbind_005f2.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE) {
          return;
        }
      } catch (Throwable _jspx_exception) {
        while (_jspx_push_body_count_spring_005fbind_005f2[0]-- > 0)
          out = _jspx_page_context.popBody();
        _jspx_th_spring_005fbind_005f2.doCatch(_jspx_exception);
      } finally {
        _jspx_th_spring_005fbind_005f2.doFinally();
        _005fjspx_005ftagPool_005fspring_005fbind_0026_005fpath.reuse(_jspx_th_spring_005fbind_005f2);
      }
      out.write("\r\n");
      out.write("\t\t\t\t\t\t\t\t\t\t\t</td>\r\n");
      out.write("\t\t\t\t\t\t\t\t\t\t\t<td colspan=\"2\" align=\"center\">\r\n");
      out.write("\t\t\t\t\t\t\t\t\t\t\t</td>\r\n");
      out.write("\t\t\t\t\t\t\t\t\t\t</tr>\r\n");
      out.write("\t\t\t\t\t\t\t\t\t\t<tr>\r\n");
      out.write("\t\t\t\t\t\t\t\t\t\t\t<td colspan=\"2\" align=\"center\">\r\n");
      out.write("\t\t\t\t\t\t\t\t\t\t\t\t");
      //  spring:bind
      org.springframework.web.servlet.tags.BindTag _jspx_th_spring_005fbind_005f3 = (org.springframework.web.servlet.tags.BindTag) _005fjspx_005ftagPool_005fspring_005fbind_0026_005fpath.get(org.springframework.web.servlet.tags.BindTag.class);
      _jspx_th_spring_005fbind_005f3.setPageContext(_jspx_page_context);
      _jspx_th_spring_005fbind_005f3.setParent(null);
      // /WEB-INF/jsp/appmentLogin.jsp(105,12) name = path type = null reqTime = true required = true fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
      _jspx_th_spring_005fbind_005f3.setPath("person.password");
      int[] _jspx_push_body_count_spring_005fbind_005f3 = new int[] { 0 };
      try {
        int _jspx_eval_spring_005fbind_005f3 = _jspx_th_spring_005fbind_005f3.doStartTag();
        if (_jspx_eval_spring_005fbind_005f3 != javax.servlet.jsp.tagext.Tag.SKIP_BODY) {
          org.springframework.web.servlet.support.BindStatus status = null;
          status = (org.springframework.web.servlet.support.BindStatus) _jspx_page_context.findAttribute("status");
          do {
            out.write("\r\n");
            out.write("\t\t\t\t\t\t\t\t\t\t\t\t\t<font color=\"red\">");
            if (_jspx_meth_c_005fout_005f2(_jspx_th_spring_005fbind_005f3, _jspx_page_context, _jspx_push_body_count_spring_005fbind_005f3))
              return;
            out.write("</font>\r\n");
            out.write("\t\t\t\t\t\t\t\t\t\t\t\t");
            int evalDoAfterBody = _jspx_th_spring_005fbind_005f3.doAfterBody();
            status = (org.springframework.web.servlet.support.BindStatus) _jspx_page_context.findAttribute("status");
            if (evalDoAfterBody != javax.servlet.jsp.tagext.BodyTag.EVAL_BODY_AGAIN)
              break;
          } while (true);
        }
        if (_jspx_th_spring_005fbind_005f3.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE) {
          return;
        }
      } catch (Throwable _jspx_exception) {
        while (_jspx_push_body_count_spring_005fbind_005f3[0]-- > 0)
          out = _jspx_page_context.popBody();
        _jspx_th_spring_005fbind_005f3.doCatch(_jspx_exception);
      } finally {
        _jspx_th_spring_005fbind_005f3.doFinally();
        _005fjspx_005ftagPool_005fspring_005fbind_0026_005fpath.reuse(_jspx_th_spring_005fbind_005f3);
      }
      out.write("\r\n");
      out.write("\t\t\t\t\t\t\t\t\t\t\t</td>\r\n");
      out.write("\t\t\t\t\t\t\t\t\t\t</tr>\t\t\t\t\t\t\r\n");
      out.write("\t\t\t\t\t\t\t\t\t</table>\r\n");
      out.write("\t\t\t\t\t\t\t\t\t</br>\r\n");
      out.write("\t\t\t\t\t\t\t\t\t<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\" height=\"30\" >    \r\n");
      out.write("\t\t\t\t\t\t\t\t\t\t<tr>  \r\n");
      out.write("\t\t\t\t\t\t\t\t\t\t\t<td  style=\"background: url(/images/submitbutton_0.png) no-repeat;overflow: hidden;background-position: top center;height:100%;\"  align=\"center\"> \t\t\t\t\t\t\t\t\t\t  \t\t\r\n");
      out.write("\t\t\t\t\t\t\t\t\t  \t\t\t<a href=\"javascript:void(0);\" onClick=\"fn_login();\" style=\"text-decoration:none\">\r\n");
      out.write("\t\t\t\t\t\t\t\t\t  \t\t\t\t<font size=\"+1\" color=\"#FFFFFF\" >Login </font> \r\n");
      out.write("\t\t\t\t\t\t\t\t\t  \t\t\t</a>\r\n");
      out.write("\t\t\t\t\t\t\t\t\t  \t\t</td>\r\n");
      out.write("\t\t\t\t\t\t\t\t\t\t</tr>\r\n");
      out.write("\t\t\t\t\t\t\t\t\t</table>\t\t\t\t\t\t\t\t\t\t\r\n");
      out.write("\t  \t\t\t\t\t\t\t\t \r\n");
      out.write("\t  \t\t\t\t\t\t\t</div>\t\t\t\t\t\t\t\r\n");
      out.write("\t\t\t\t\t\t\t</div>\r\n");
      out.write("\t\t\t\t\t\t\t<div class=\"stp\" style=\"margin-bottom:1.5em;\" >\r\n");
      out.write("\t  \t\t\t\t\t\t\t<div class=\"or\" style=\"margin:1em; padding:0;\" > \r\n");
      out.write("\t  \t\t\t\t\t\t\t\t<span style=\"font-size:1.3em;font-color:black;font:Verdana\" >Don't have account yet?</span><br />   \r\n");
      out.write("\t  \t\t\t\t\t\t\t\t<a href=\"/appmentSignUp.htm\" onMouseover=\"document.buttonimg1.src=eval('cacheonimg.src')\" onMouseout=\"document.buttonimg1.src=eval('cacheoffimg.src')\">\r\n");
      out.write("\t  \t\t\t\t\t\t\t\t\t<img src=\"/images/MCbutton_0.png\" name=\"buttonimg1\" width=\"170\" height=\"68\" alt=\"AppMent-Create a new Account\">   \r\n");
      out.write("\t  \t\t\t\t\t\t\t\t</a>\r\n");
      out.write("\t  \t\t\t\t\t\t\t</div>\t\t\t\t\t\t\t\r\n");
      out.write("\t\t\t\t\t\t\t</div>\r\n");
      out.write("\t\t\t\t\t\t</form>\r\n");
      out.write("\t\t\t\t\t\t</div>\r\n");
      out.write("\t\t\t\t\t</div>\r\n");
      out.write("\t\t\t\t\t</div>\r\n");
      out.write("\t\t\t\t\t</div>\r\n");
      out.write("\t\t\t\t</div>\r\n");
      out.write("\t\t\t</div> \r\n");
      out.write("\t\t</div>\r\n");
      out.write("\t<script type=\"text/javascript\" src=\"");
      out.print(request.getContextPath());
      out.write("/js/jquery-1.2.6.min.js\"></script>\r\n");
      out.write("\t<script type=\"text/javascript\" src=\"");
      out.print(request.getContextPath());
      out.write("/js/openid-jquery.js\"></script>\r\n");
      out.write("\t<script type=\"text/javascript\" src=\"");
      out.print(request.getContextPath());
      out.write("/js/openid-jquery-en.js\"></script>\r\n");
      out.write("\t<script type=\"text/javascript\">\t \r\n");
      out.write("\t//  var $j = jQuery.noConflict();\r\n");
      out.write("\t\t\r\n");
      out.write("\t$(document).ready(function() {\r\n");
      out.write("\t    openid.init('openid_identifier');\r\n");
      out.write("\t    openid.setDemoMode(true); //Stops form submission for client javascript-only test purposes\r\n");
      out.write("\t});\r\n");
      out.write("\t\r\n");
      out.write("\t</script>\r\n");
      out.write("\t\t\r\n");
      out.write("<script type=\"text/javascript\">\r\n");
      out.write("$.jGrowl('You can book appointment, postpone it or cancel it by sending SMS.Following are the commands:', \r\n");
      out.write("   {header: 'SMS Support!' ,life: 10000}\r\n");
      out.write("  );\r\n");
      out.write("$.jGrowl('1. To schedule an appointment with a fellow appmate at certain date and time SCD [yourusername] [mm/dd/yyyy] [hh:mm:ss] [duration hh:mm:ss] [appmateusername] ', \r\n");
      out.write("\t   {life: 10000}\r\n");
      out.write(" );\r\n");
      out.write("$.jGrowl('2. To postpone any appointment that you have already scheduleRESCD [yourusername] [old mm/dd/yyyy] [old hh:mm:ss] [new mm/dd/yyyy] [new hh:mm:ss] [duration hh:mm:ss]', \r\n");
      out.write("\t\t   {life: 10000}\r\n");
      out.write("\t );\r\n");
      out.write("$.jGrowl('3. To cancel any appointment that you have already scheduleCANCEL [yourusername] [mm/dd/yyyy] [hh:mm:ss]', \r\n");
      out.write("\t\t   {life: 10000}\r\n");
      out.write("\t );\r\n");
      out.write("</script>\r\n");
      out.write("\r\n");
      out.write("<div id=\"contentFootLeft\">\r\n");
      out.write("\t\t\r\n");
      out.write("\t\t\t<div id=\"contentFootRight\">\r\n");
      out.write("\t\t\t\t<div id=\"contentFootCenter\"/>\r\n");
      out.write("\t\t\t</div>\r\n");
      out.write("\t\t</div>\r\n");
      out.write("\t\t<div id=\"footer\">\r\n");
      out.write("\t\t\t<p id=\"copyright\"></p>\r\n");
      out.write("\t\t\t<p id=\"info\">\r\n");
      out.write("\t\t\t\tBeta 1.0\r\n");
      out.write("\t\t\t</p>\r\n");
      out.write("\t\t</div>\r\n");
      out.write("\t</div>\r\n");
      out.write("    <script type=\"text/javascript\" src=\"");
      out.print(request.getContextPath());
      out.write("/js/mediapp.js\"></script>\r\n");
      out.write("<!-- Attach events to Link -->\r\n");
      out.write("<div id=\"helpbox\"></div>\r\n");
      out.write("\r\n");
      out.write("</body>\r\n");
      out.write("\r\n");
      out.write("</html>\r\n");
      out.write('\r');
      out.write('\n');
    } catch (Throwable t) {
      if (!(t instanceof SkipPageException)){
        out = _jspx_out;
        if (out != null && out.getBufferSize() != 0)
          try { out.clearBuffer(); } catch (java.io.IOException e) {}
        if (_jspx_page_context != null) _jspx_page_context.handlePageException(t);
      }
    } finally {
      _jspxFactory.releasePageContext(_jspx_page_context);
    }
  }

  private boolean _jspx_meth_c_005fout_005f0(javax.servlet.jsp.tagext.JspTag _jspx_th_spring_005fbind_005f0, PageContext _jspx_page_context, int[] _jspx_push_body_count_spring_005fbind_005f0)
          throws Throwable {
    PageContext pageContext = _jspx_page_context;
    JspWriter out = _jspx_page_context.getOut();
    //  c:out
    org.apache.taglibs.standard.tag.rt.core.OutTag _jspx_th_c_005fout_005f0 = (org.apache.taglibs.standard.tag.rt.core.OutTag) _005fjspx_005ftagPool_005fc_005fout_0026_005fvalue_005fnobody.get(org.apache.taglibs.standard.tag.rt.core.OutTag.class);
    _jspx_th_c_005fout_005f0.setPageContext(_jspx_page_context);
    _jspx_th_c_005fout_005f0.setParent((javax.servlet.jsp.tagext.Tag) _jspx_th_spring_005fbind_005f0);
    // /WEB-INF/jsp/appmentLogin.jsp(77,71) name = value type = null reqTime = true required = true fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
    _jspx_th_c_005fout_005f0.setValue((java.lang.Object) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${status.value}", java.lang.Object.class, (PageContext)_jspx_page_context, null, false));
    int _jspx_eval_c_005fout_005f0 = _jspx_th_c_005fout_005f0.doStartTag();
    if (_jspx_th_c_005fout_005f0.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE) {
      _005fjspx_005ftagPool_005fc_005fout_0026_005fvalue_005fnobody.reuse(_jspx_th_c_005fout_005f0);
      return true;
    }
    _005fjspx_005ftagPool_005fc_005fout_0026_005fvalue_005fnobody.reuse(_jspx_th_c_005fout_005f0);
    return false;
  }

  private boolean _jspx_meth_c_005fout_005f1(javax.servlet.jsp.tagext.JspTag _jspx_th_spring_005fbind_005f1, PageContext _jspx_page_context, int[] _jspx_push_body_count_spring_005fbind_005f1)
          throws Throwable {
    PageContext pageContext = _jspx_page_context;
    JspWriter out = _jspx_page_context.getOut();
    //  c:out
    org.apache.taglibs.standard.tag.rt.core.OutTag _jspx_th_c_005fout_005f1 = (org.apache.taglibs.standard.tag.rt.core.OutTag) _005fjspx_005ftagPool_005fc_005fout_0026_005fvalue_005fnobody.get(org.apache.taglibs.standard.tag.rt.core.OutTag.class);
    _jspx_th_c_005fout_005f1.setPageContext(_jspx_page_context);
    _jspx_th_c_005fout_005f1.setParent((javax.servlet.jsp.tagext.Tag) _jspx_th_spring_005fbind_005f1);
    // /WEB-INF/jsp/appmentLogin.jsp(88,32) name = value type = null reqTime = true required = true fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
    _jspx_th_c_005fout_005f1.setValue((java.lang.Object) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${status.errorMessage}", java.lang.Object.class, (PageContext)_jspx_page_context, null, false));
    int _jspx_eval_c_005fout_005f1 = _jspx_th_c_005fout_005f1.doStartTag();
    if (_jspx_th_c_005fout_005f1.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE) {
      _005fjspx_005ftagPool_005fc_005fout_0026_005fvalue_005fnobody.reuse(_jspx_th_c_005fout_005f1);
      return true;
    }
    _005fjspx_005ftagPool_005fc_005fout_0026_005fvalue_005fnobody.reuse(_jspx_th_c_005fout_005f1);
    return false;
  }

  private boolean _jspx_meth_c_005fout_005f2(javax.servlet.jsp.tagext.JspTag _jspx_th_spring_005fbind_005f3, PageContext _jspx_page_context, int[] _jspx_push_body_count_spring_005fbind_005f3)
          throws Throwable {
    PageContext pageContext = _jspx_page_context;
    JspWriter out = _jspx_page_context.getOut();
    //  c:out
    org.apache.taglibs.standard.tag.rt.core.OutTag _jspx_th_c_005fout_005f2 = (org.apache.taglibs.standard.tag.rt.core.OutTag) _005fjspx_005ftagPool_005fc_005fout_0026_005fvalue_005fnobody.get(org.apache.taglibs.standard.tag.rt.core.OutTag.class);
    _jspx_th_c_005fout_005f2.setPageContext(_jspx_page_context);
    _jspx_th_c_005fout_005f2.setParent((javax.servlet.jsp.tagext.Tag) _jspx_th_spring_005fbind_005f3);
    // /WEB-INF/jsp/appmentLogin.jsp(106,31) name = value type = null reqTime = true required = true fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
    _jspx_th_c_005fout_005f2.setValue((java.lang.Object) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${status.errorMessage}", java.lang.Object.class, (PageContext)_jspx_page_context, null, false));
    int _jspx_eval_c_005fout_005f2 = _jspx_th_c_005fout_005f2.doStartTag();
    if (_jspx_th_c_005fout_005f2.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE) {
      _005fjspx_005ftagPool_005fc_005fout_0026_005fvalue_005fnobody.reuse(_jspx_th_c_005fout_005f2);
      return true;
    }
    _005fjspx_005ftagPool_005fc_005fout_0026_005fvalue_005fnobody.reuse(_jspx_th_c_005fout_005f2);
    return false;
  }
}
