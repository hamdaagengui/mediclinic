package org.apache.jsp.WEB_002dINF.jsp;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import com.mediapp.domain.common.Person;

public final class pastHistory_jsp extends org.apache.jasper.runtime.HttpJspBase
    implements org.apache.jasper.runtime.JspSourceDependent {

static private org.apache.jasper.runtime.ProtectedFunctionMapper _jspx_fnmap_0;

static {
  _jspx_fnmap_0= org.apache.jasper.runtime.ProtectedFunctionMapper.getMapForFunction("fn:trim", org.apache.taglibs.standard.functions.Functions.class, "trim", new Class[] {java.lang.String.class});
}

  private static final JspFactory _jspxFactory = JspFactory.getDefaultFactory();

  private static java.util.List _jspx_dependants;

  static {
    _jspx_dependants = new java.util.ArrayList(3);
    _jspx_dependants.add("/WEB-INF/jsp/include.jsp");
    _jspx_dependants.add("/WEB-INF/jsp/footer.jsp");
    _jspx_dependants.add("/WEB-INF/tld/verticalMenuItemTag.tld");
  }

  private org.apache.jasper.runtime.TagHandlerPool _005fjspx_005ftagPool_005fmenu_005fverticalMenuItemTag_005fnobody;
  private org.apache.jasper.runtime.TagHandlerPool _005fjspx_005ftagPool_005fspring_005fbind_0026_005fpath;
  private org.apache.jasper.runtime.TagHandlerPool _005fjspx_005ftagPool_005fc_005fout_0026_005fvalue_005fnobody;
  private org.apache.jasper.runtime.TagHandlerPool _005fjspx_005ftagPool_005fc_005fforEach_0026_005fvarStatus_005fitems;

  private javax.el.ExpressionFactory _el_expressionfactory;
  private org.apache.AnnotationProcessor _jsp_annotationprocessor;

  public Object getDependants() {
    return _jspx_dependants;
  }

  public void _jspInit() {
    _005fjspx_005ftagPool_005fmenu_005fverticalMenuItemTag_005fnobody = org.apache.jasper.runtime.TagHandlerPool.getTagHandlerPool(getServletConfig());
    _005fjspx_005ftagPool_005fspring_005fbind_0026_005fpath = org.apache.jasper.runtime.TagHandlerPool.getTagHandlerPool(getServletConfig());
    _005fjspx_005ftagPool_005fc_005fout_0026_005fvalue_005fnobody = org.apache.jasper.runtime.TagHandlerPool.getTagHandlerPool(getServletConfig());
    _005fjspx_005ftagPool_005fc_005fforEach_0026_005fvarStatus_005fitems = org.apache.jasper.runtime.TagHandlerPool.getTagHandlerPool(getServletConfig());
    _el_expressionfactory = _jspxFactory.getJspApplicationContext(getServletConfig().getServletContext()).getExpressionFactory();
    _jsp_annotationprocessor = (org.apache.AnnotationProcessor) getServletConfig().getServletContext().getAttribute(org.apache.AnnotationProcessor.class.getName());
  }

  public void _jspDestroy() {
    _005fjspx_005ftagPool_005fmenu_005fverticalMenuItemTag_005fnobody.release();
    _005fjspx_005ftagPool_005fspring_005fbind_0026_005fpath.release();
    _005fjspx_005ftagPool_005fc_005fout_0026_005fvalue_005fnobody.release();
    _005fjspx_005ftagPool_005fc_005fforEach_0026_005fvarStatus_005fitems.release();
  }

  public void _jspService(HttpServletRequest request, HttpServletResponse response)
        throws java.io.IOException, ServletException {

    PageContext pageContext = null;
    HttpSession session = null;
    ServletContext application = null;
    ServletConfig config = null;
    JspWriter out = null;
    Object page = this;
    JspWriter _jspx_out = null;
    PageContext _jspx_page_context = null;


    try {
      response.setContentType("text/html");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			null, true, 8192, true);
      _jspx_page_context = pageContext;
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      session = pageContext.getSession();
      out = pageContext.getOut();
      _jspx_out = out;

      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("    \r\n");
      out.write("    \r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("<html>\r\n");
      out.write("<head>\r\n");
 response.setHeader("Expires","Mon, 26 Jul 2020 05:00:00 GMT"); 
      out.write("\r\n");
      out.write("    <title>AppMent</title>\r\n");
      out.write("\t<link rel=\"shortcut icon\" href=\"");
      out.print(request.getContextPath());
      out.write("/images/shakehand1.ico\" type=\"image/x-icon\" />    \r\n");
      out.write("\t<link rel=\"stylesheet\" href=\"");
      out.print(request.getContextPath());
      out.write("/css/jquery-ui.css\" type=\"text/css\" />\r\n");
      out.write("\t<link href=\"");
      out.print(request.getContextPath());
      out.write("/css/mycss.css\" rel=\"stylesheet\" type=\"text/css\">\r\n");
      out.write("    <script type=\"text/javascript\"  src=\"");
      out.print(request.getContextPath());
      out.write("/js/jquery.min.js\"></script>\r\n");
      out.write("    <script type=\"text/javascript\"  src=\"");
      out.print(request.getContextPath());
      out.write("/js/jquery-ui.min.js\"></script>\r\n");
      out.write("\t<script type=\"text/javascript\" src=\"");
      out.print(request.getContextPath());
      out.write("/js/customalert.js\" ></script>\r\n");
      out.write("\t<script type=\"text/javascript\" src=\"");
      out.print(request.getContextPath());
      out.write("/js/prototype.js\"></script>\r\n");
      out.write("\t<script type=\"text/javascript\" src=\"");
      out.print(request.getContextPath());
      out.write("/js/autocomplete.js\"></script>\r\n");
      out.write("\t<script type=\"text/javascript\" src=\"");
      out.print(request.getContextPath());
      out.write("/js/calendar_us.js\"></script>\t\r\n");
      out.write("\t\r\n");
      out.write("\r\n");
      out.write("</head>\r\n");
      out.write("<body >\r\n");
      out.write("\t<div id=\"main\">\r\n");
      out.write("\t\t");
Person p = (Person)request.getSession().getAttribute("person"); 
      out.write("\r\n");
      out.write("\t\t\t");
if (p != null && p.getPersonTypeString() != null && p.getPersonTypeString().equals("Doctor")) {
      out.write(" \r\n");
      out.write("\t\r\n");
      out.write("\t\t<div id=\"header\" style=\"background: url(/images/medical.jpg) no-repeat;\">\r\n");
      out.write("\t\t\t<div id=\"name\">\r\n");
      out.write("\t\t\t\t<h3> MediApp\r\n");
      out.write("\t\t\t\t</h3>\r\n");
      out.write("\t\t\t\t<h4> Easy way to get medical attention!\r\n");
      out.write("\t\t\t\t</h4>\r\n");
      out.write("\t\r\n");
      out.write("\t\t\t</div>\r\n");
      out.write("\t\t\t<div id=\"controls\">\r\n");
      out.write("\t\t\t\t\t<form id=\"searchform\" action=\"");
      out.print(request.getContextPath());
      out.write("\" method=\"post\">\r\n");
      out.write("\t\t\t\t        ");

				        	if (p != null) {
      out.write("\r\n");
      out.write("\t\t\t\t\t\t        <a href=\"logOut.htm\" >Logout</a>\r\n");
      out.write("\t\t\t\t        ");
} 
      out.write("\r\n");
      out.write("\t\t\t\t\t</form>\r\n");
      out.write("\t\t\t</div>\r\n");
      out.write("\t\t</div>\r\n");
      out.write("\t\t");
}else{ 
      out.write("\r\n");
      out.write("\t\t<div id=\"header\" >\r\n");
      out.write("\t\t\t<div id=\"name\">\r\n");
      out.write("\t\t\t\t<h3> AppMent\r\n");
      out.write("\t\t\t\t</h3>\r\n");
      out.write("\t\t\t\t<h4> <font color=\"grey\">Easy way to get organized!</font>\r\n");
      out.write("\t\t\t\t</h4>\r\n");
      out.write("\t\r\n");
      out.write("\t\t\t</div>\r\n");
      out.write("\t\t\t<div id=\"controls\">\r\n");
      out.write("\t\t\t\t\t<form id=\"searchform\" action=\"");
      out.print(request.getContextPath());
      out.write("\" method=\"post\">\t\t\t\t\t\r\n");
      out.write("\t\t\t\t\t<a href=\"http://www.facebook.com/apps/application.php?id=152456314791817&v=info\" TARGET=\"_blank\">\r\n");
      out.write("\t\t\t\t\t<img src=\"/images/Facebook-Buttons-11-2.png\" title=\"Find us on Facebook\"  \r\n");
      out.write("\t\t\t\t\talt=\"Find us on Facebook\" width=\"21px\" border=\"0\"/></a><br/>\r\n");
      out.write("\t\t\t\t\t\r\n");
      out.write("\t\t\t\t        ");

				        	if (p != null) {
      out.write("\r\n");
      out.write("\t\t\t\t\t\t        <a href=\"logOut.htm\" >Logout</a>\r\n");
      out.write("\t\t\t\t        ");
} 
      out.write("\r\n");
      out.write("\t\t\t\t\t</form>\r\n");
      out.write("\t\t\t</div>\r\n");
      out.write("\t\t</div>\r\n");
      out.write("\t\t\r\n");
      out.write("\t\t");
} 
      out.write("\t\r\n");
      out.write("<div >\r\n");
      out.write("\t\t\t\t\t\t\t\r\n");
      out.write("\t\t\t\t\t\t\t\t<div align=\"right\">\t\t\r\n");
      out.write("\t\t\t\t\t\t\t\t\t\t\t\t\t \t\t\t\t\t\t\t\t\t\r\n");
      out.write("\t\t\t\t\t\t\t\t");

									if (p != null && p.getFirstName()==null){
										out.print("Welcome " + p.getUsername() );
									}else if(p != null && p.getFirstName()!=null){
										out.print("Welcome " + p.getFirstName() );
									}
								
      out.write("\r\n");
      out.write("\t\t\t\t\t\t\t\t\r\n");
      out.write("\t\t\t\t\t\t\t\t</div>\r\n");
      out.write("</div>\r\n");
      out.write("\t\t<div id=\"contentHeadLeft\">\r\n");
      out.write("\t\t\t<div id=\"contentHeadRight\">\r\n");
      out.write("\t\t\t\t\r\n");
      out.write("\t\t\t\t<div id=\"contentHeadCenter\">\r\n");
      out.write("\t\t\t\t\t\t\t\t<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"200\" height=\"30\" >      \r\n");
      out.write("\t\t\t\t\t\t\t\t\t<tr >     \r\n");
      out.write("\t\t\t\t\t\t\t\t\t\t<td  >  \r\n");
      out.write("\t\t\t\t\t\t\t\t  \t\t\t<a href=\"/welcomePage.htm\" onClick=\"\" style=\"text-decoration:none\">\r\n");
      out.write("\t\t\t\t\t\t\t\t  \t\t\t<img src=\"/images/Home11.png\" ></img>\r\n");
      out.write("\t\t\t\t\t\t\t\t  \t\t\t</a>\r\n");
      out.write("\t\t\t\t\t\t\t\t  \t\t</td>\r\n");
      out.write("\t\t\t\t\t\t\t\t  \t\t<td align=\"center\">\r\n");
      out.write("\t\t\t\t\t\t\t\t  \t\t<img src=\"/images/phone11.png\"  onMouseover=\"showbox(event,'You can book appointment, postpone it or cancel it by sending SMS.</br>Following are the commands</br>1. To schedule an appointment with a fellow appmate at certain date and time</br>SCD &amp;lt;yourusername&amp;gt; &amp;lt;mm/dd/yyyy&amp;gt; &amp;lt;hh:mm:ss&amp;gt; &amp;lt;duration hh:mm:ss&amp;gt; &amp;lt;appmateusername&amp;gt; </br>2. To postpone any appointment that you have already schedule</br>RESCD &amp;lt;yourusername&amp;gt; &amp;lt;old mm/dd/yyyy&amp;gt; &amp;lt;old hh:mm:ss&amp;gt; &amp;lt;new mm/dd/yyyy&amp;gt; &amp;lt;new hh:mm:ss&amp;gt; &amp;lt;duration hh:mm:ss&amp;gt; </br>3. To cancel any appointment that you have already schedule</br>CANCEL &amp;lt;yourusername&amp;gt; &amp;lt;mm/dd/yyyy&amp;gt; &amp;lt;hh:mm:ss&amp;gt;</br>');\" onMouseout=\"hidebox();\"/>\r\n");
      out.write("\t\t\t\t\t\t\t\t  \t\t</td>\r\n");
      out.write("\t\t\t\t\t\t\t\t\t\r\n");
      out.write("\t\t\t\t\t\t\t\t\t</tr>\r\n");
      out.write("\t\t\t\t\t\t\t\t</table>\t\t\t\t\t\t\t\t\t\t\r\n");
      out.write("\t\t\t\t\t\t\t\r\n");
      out.write("\t\t\t\t</div>\r\n");
      out.write("\t\t\t</div>\t\t\r\n");
      out.write("\t\t</div>\r\n");
      out.write("\r\n");
      out.write("<div id=\"contentBodyLeft\">\r\n");
      out.write("   <div id=\"contentBodyRight\">\r\n");
      out.write("    <div id=\"contentBodyCenter\">\r\n");
      out.write("    \t\t\t<div class=\"stp\" style=\"margin-bottom:1.5em;\">\r\n");
      out.write("\t\t\t\t<div class=\"or\" style=\"margin:1em; padding:0;\" >\r\n");
      out.write("    \r\n");
      out.write("     <div id=\"contentSingleEntry\" style=\"\">\r\n");
      out.write("      <div id=\"entries\">\r\n");
      out.write("       <div class=\"entryAlone\">\r\n");
      out.write("        <form name=\"pastHistory\" id=\"pastHistory\" method=\"post\" >\r\n");
      out.write("         <table width=900  border=\"1\" class=\"layout\"  > \r\n");
      out.write("          <tr>\r\n");
      out.write("           <td> \r\n");
      out.write("             <table width=200 align=\"left\"   class=\"sample\" style=\"border-width: 0px 0px 0px 0px;\">  \r\n");
      out.write("             ");
      if (_jspx_meth_menu_005fverticalMenuItemTag_005f0(_jspx_page_context))
        return;
      out.write("\r\n");
      out.write("            </table>\r\n");
      out.write("            \r\n");
      out.write("            <div id=\"History\"  style=\"display:block\" align=\"center\">\r\n");
      out.write("             <table  border=\"\"  class=\"sample\" width=680 cellpadding=\"200\">\r\n");
      out.write("              <tr  >\r\n");
      out.write("               Personal Information\r\n");
      out.write("              </tr>\r\n");
      out.write("              <tr>\r\n");
      out.write("              \t\t");
      //  spring:bind
      org.springframework.web.servlet.tags.BindTag _jspx_th_spring_005fbind_005f0 = (org.springframework.web.servlet.tags.BindTag) _005fjspx_005ftagPool_005fspring_005fbind_0026_005fpath.get(org.springframework.web.servlet.tags.BindTag.class);
      _jspx_th_spring_005fbind_005f0.setPageContext(_jspx_page_context);
      _jspx_th_spring_005fbind_005f0.setParent(null);
      // /WEB-INF/jsp/pastHistory.jsp(25,16) name = path type = null reqTime = true required = true fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
      _jspx_th_spring_005fbind_005f0.setPath("patientDetails.idPatient");
      int[] _jspx_push_body_count_spring_005fbind_005f0 = new int[] { 0 };
      try {
        int _jspx_eval_spring_005fbind_005f0 = _jspx_th_spring_005fbind_005f0.doStartTag();
        if (_jspx_eval_spring_005fbind_005f0 != javax.servlet.jsp.tagext.Tag.SKIP_BODY) {
          org.springframework.web.servlet.support.BindStatus status = null;
          status = (org.springframework.web.servlet.support.BindStatus) _jspx_page_context.findAttribute("status");
          do {
            out.write("\r\n");
            out.write("\t\t\t\t\t\t<input type=\"hidden\" name=\"");
            out.write((java.lang.String) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${status.expression}", java.lang.String.class, (PageContext)_jspx_page_context, null, false));
            out.write("\"  value=\"");
            if (_jspx_meth_c_005fout_005f0(_jspx_th_spring_005fbind_005f0, _jspx_page_context, _jspx_push_body_count_spring_005fbind_005f0))
              return;
            out.write("\"/>\t\t\t\t\t\r\n");
            out.write("\t\t\t\t\t");
            int evalDoAfterBody = _jspx_th_spring_005fbind_005f0.doAfterBody();
            status = (org.springframework.web.servlet.support.BindStatus) _jspx_page_context.findAttribute("status");
            if (evalDoAfterBody != javax.servlet.jsp.tagext.BodyTag.EVAL_BODY_AGAIN)
              break;
          } while (true);
        }
        if (_jspx_th_spring_005fbind_005f0.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE) {
          return;
        }
      } catch (Throwable _jspx_exception) {
        while (_jspx_push_body_count_spring_005fbind_005f0[0]-- > 0)
          out = _jspx_page_context.popBody();
        _jspx_th_spring_005fbind_005f0.doCatch(_jspx_exception);
      } finally {
        _jspx_th_spring_005fbind_005f0.doFinally();
        _005fjspx_005ftagPool_005fspring_005fbind_0026_005fpath.reuse(_jspx_th_spring_005fbind_005f0);
      }
      out.write("\r\n");
      out.write("              \r\n");
      out.write("               <td >Weight: </td>\r\n");
      out.write("               <td >\r\n");
      out.write("                ");
      //  spring:bind
      org.springframework.web.servlet.tags.BindTag _jspx_th_spring_005fbind_005f1 = (org.springframework.web.servlet.tags.BindTag) _005fjspx_005ftagPool_005fspring_005fbind_0026_005fpath.get(org.springframework.web.servlet.tags.BindTag.class);
      _jspx_th_spring_005fbind_005f1.setPageContext(_jspx_page_context);
      _jspx_th_spring_005fbind_005f1.setParent(null);
      // /WEB-INF/jsp/pastHistory.jsp(31,16) name = path type = null reqTime = true required = true fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
      _jspx_th_spring_005fbind_005f1.setPath("patientDetails.weight");
      int[] _jspx_push_body_count_spring_005fbind_005f1 = new int[] { 0 };
      try {
        int _jspx_eval_spring_005fbind_005f1 = _jspx_th_spring_005fbind_005f1.doStartTag();
        if (_jspx_eval_spring_005fbind_005f1 != javax.servlet.jsp.tagext.Tag.SKIP_BODY) {
          org.springframework.web.servlet.support.BindStatus status = null;
          status = (org.springframework.web.servlet.support.BindStatus) _jspx_page_context.findAttribute("status");
          do {
            out.write("                               \r\n");
            out.write("                 <input type=\"text\"  name=\"weight\"  value=\"");
            if (_jspx_meth_c_005fout_005f1(_jspx_th_spring_005fbind_005f1, _jspx_page_context, _jspx_push_body_count_spring_005fbind_005f1))
              return;
            out.write("\" style=\"WIDTH: 50px\" onKeyUp=\"if(this.value.match(/\\D/))this.value=this.value.replace(/\\D/g,'')\" onblur=\"if(this.value.match(/\\D/))this.value=this.value.replace(/\\D/g,'')\" maxlength=\"3\"/>\r\n");
            out.write("                 kg\r\n");
            out.write("                 <font color=\"red\">");
            if (_jspx_meth_c_005fout_005f2(_jspx_th_spring_005fbind_005f1, _jspx_page_context, _jspx_push_body_count_spring_005fbind_005f1))
              return;
            out.write("</font>\r\n");
            out.write("                ");
            int evalDoAfterBody = _jspx_th_spring_005fbind_005f1.doAfterBody();
            status = (org.springframework.web.servlet.support.BindStatus) _jspx_page_context.findAttribute("status");
            if (evalDoAfterBody != javax.servlet.jsp.tagext.BodyTag.EVAL_BODY_AGAIN)
              break;
          } while (true);
        }
        if (_jspx_th_spring_005fbind_005f1.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE) {
          return;
        }
      } catch (Throwable _jspx_exception) {
        while (_jspx_push_body_count_spring_005fbind_005f1[0]-- > 0)
          out = _jspx_page_context.popBody();
        _jspx_th_spring_005fbind_005f1.doCatch(_jspx_exception);
      } finally {
        _jspx_th_spring_005fbind_005f1.doFinally();
        _005fjspx_005ftagPool_005fspring_005fbind_0026_005fpath.reuse(_jspx_th_spring_005fbind_005f1);
      }
      out.write("\r\n");
      out.write("                \r\n");
      out.write("               </td>\r\n");
      out.write("               <td >Height: </td>\r\n");
      out.write("               <td >\r\n");
      out.write("                ");
      //  spring:bind
      org.springframework.web.servlet.tags.BindTag _jspx_th_spring_005fbind_005f2 = (org.springframework.web.servlet.tags.BindTag) _005fjspx_005ftagPool_005fspring_005fbind_0026_005fpath.get(org.springframework.web.servlet.tags.BindTag.class);
      _jspx_th_spring_005fbind_005f2.setPageContext(_jspx_page_context);
      _jspx_th_spring_005fbind_005f2.setParent(null);
      // /WEB-INF/jsp/pastHistory.jsp(40,16) name = path type = null reqTime = true required = true fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
      _jspx_th_spring_005fbind_005f2.setPath("patientDetails.height");
      int[] _jspx_push_body_count_spring_005fbind_005f2 = new int[] { 0 };
      try {
        int _jspx_eval_spring_005fbind_005f2 = _jspx_th_spring_005fbind_005f2.doStartTag();
        if (_jspx_eval_spring_005fbind_005f2 != javax.servlet.jsp.tagext.Tag.SKIP_BODY) {
          org.springframework.web.servlet.support.BindStatus status = null;
          status = (org.springframework.web.servlet.support.BindStatus) _jspx_page_context.findAttribute("status");
          do {
            out.write("                               \r\n");
            out.write("                 <input type=\"text\"  name=\"height\"  value=\"");
            if (_jspx_meth_c_005fout_005f3(_jspx_th_spring_005fbind_005f2, _jspx_page_context, _jspx_push_body_count_spring_005fbind_005f2))
              return;
            out.write("\" style=\"WIDTH: 50px\" onKeyUp=\"if(this.value.match(/\\D/))this.value=this.value.replace(/\\D/g,'')\" onblur=\"if(this.value.match(/\\D/))this.value=this.value.replace(/\\D/g,'')\" maxlength=\"3\"/>\r\n");
            out.write("                 cm\r\n");
            out.write("                 <font color=\"red\">");
            if (_jspx_meth_c_005fout_005f4(_jspx_th_spring_005fbind_005f2, _jspx_page_context, _jspx_push_body_count_spring_005fbind_005f2))
              return;
            out.write("</font>\r\n");
            out.write("                ");
            int evalDoAfterBody = _jspx_th_spring_005fbind_005f2.doAfterBody();
            status = (org.springframework.web.servlet.support.BindStatus) _jspx_page_context.findAttribute("status");
            if (evalDoAfterBody != javax.servlet.jsp.tagext.BodyTag.EVAL_BODY_AGAIN)
              break;
          } while (true);
        }
        if (_jspx_th_spring_005fbind_005f2.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE) {
          return;
        }
      } catch (Throwable _jspx_exception) {
        while (_jspx_push_body_count_spring_005fbind_005f2[0]-- > 0)
          out = _jspx_page_context.popBody();
        _jspx_th_spring_005fbind_005f2.doCatch(_jspx_exception);
      } finally {
        _jspx_th_spring_005fbind_005f2.doFinally();
        _005fjspx_005ftagPool_005fspring_005fbind_0026_005fpath.reuse(_jspx_th_spring_005fbind_005f2);
      }
      out.write("\r\n");
      out.write("                \r\n");
      out.write("               </td>\r\n");
      out.write("               \r\n");
      out.write("              </tr>\r\n");
      out.write("              <tr>\r\n");
      out.write("               <td >Blood Group: </td>\r\n");
      out.write("               <td >\r\n");
      out.write("                ");
      //  spring:bind
      org.springframework.web.servlet.tags.BindTag _jspx_th_spring_005fbind_005f3 = (org.springframework.web.servlet.tags.BindTag) _005fjspx_005ftagPool_005fspring_005fbind_0026_005fpath.get(org.springframework.web.servlet.tags.BindTag.class);
      _jspx_th_spring_005fbind_005f3.setPageContext(_jspx_page_context);
      _jspx_th_spring_005fbind_005f3.setParent(null);
      // /WEB-INF/jsp/pastHistory.jsp(52,16) name = path type = null reqTime = true required = true fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
      _jspx_th_spring_005fbind_005f3.setPath("patientDetails.bloodGroup");
      int[] _jspx_push_body_count_spring_005fbind_005f3 = new int[] { 0 };
      try {
        int _jspx_eval_spring_005fbind_005f3 = _jspx_th_spring_005fbind_005f3.doStartTag();
        if (_jspx_eval_spring_005fbind_005f3 != javax.servlet.jsp.tagext.Tag.SKIP_BODY) {
          org.springframework.web.servlet.support.BindStatus status = null;
          status = (org.springframework.web.servlet.support.BindStatus) _jspx_page_context.findAttribute("status");
          do {
            out.write("\r\n");
            out.write("                 <select id=\"bloodGroup\" name=\"bloodGroup\" style=\"WIDTH: 100px\">\r\n");
            out.write("                   <option value='' >-Select-</option>               \t\r\n");
            out.write("                   <option value='A+' ");
            out.write((java.lang.String) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${patientDetails.bloodGroup=='A+'?\"selected=\\\"selected\\\"\":\"\" }", java.lang.String.class, (PageContext)_jspx_page_context, null, false));
            out.write(">A+</option>\r\n");
            out.write("                   <option value='A-' ");
            out.write((java.lang.String) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${patientDetails.bloodGroup=='A-'?\"selected=\\\"selected\\\"\":\"\" }", java.lang.String.class, (PageContext)_jspx_page_context, null, false));
            out.write(">A-</option>\r\n");
            out.write("                   <option value='B+' ");
            out.write((java.lang.String) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${patientDetails.bloodGroup=='B+'?\"selected=\\\"selected\\\"\":\"\" }", java.lang.String.class, (PageContext)_jspx_page_context, null, false));
            out.write(" >B+</option>\r\n");
            out.write("                   <option value='B-' ");
            out.write((java.lang.String) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${patientDetails.bloodGroup=='B-'?\"selected=\\\"selected\\\"\":\"\" }", java.lang.String.class, (PageContext)_jspx_page_context, null, false));
            out.write(">B-</option>\r\n");
            out.write("                   <option value='AB+' ");
            out.write((java.lang.String) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${patientDetails.bloodGroup=='AB+'?\"selected=\\\"selected\\\"\":\"\" }", java.lang.String.class, (PageContext)_jspx_page_context, null, false));
            out.write(">AB+</option>\r\n");
            out.write("                   <option value='AB-' ");
            out.write((java.lang.String) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${patientDetails.bloodGroup=='AB-'?\"selected=\\\"selected\\\"\":\"\" }", java.lang.String.class, (PageContext)_jspx_page_context, null, false));
            out.write(">AB-</option>\r\n");
            out.write("                   <option value='O+' ");
            out.write((java.lang.String) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${patientDetails.bloodGroup=='O+'?\"selected=\\\"selected\\\"\" :\"\"}", java.lang.String.class, (PageContext)_jspx_page_context, null, false));
            out.write(">O+</option>\r\n");
            out.write("                   <option value='O-' ");
            out.write((java.lang.String) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${patientDetails.bloodGroup=='O-'?\"selected=\\\"selected\\\"\":\"\" }", java.lang.String.class, (PageContext)_jspx_page_context, null, false));
            out.write(">O-</option>\r\n");
            out.write("                   \r\n");
            out.write("                   \r\n");
            out.write("                 </select>\r\n");
            out.write("                ");
            int evalDoAfterBody = _jspx_th_spring_005fbind_005f3.doAfterBody();
            status = (org.springframework.web.servlet.support.BindStatus) _jspx_page_context.findAttribute("status");
            if (evalDoAfterBody != javax.servlet.jsp.tagext.BodyTag.EVAL_BODY_AGAIN)
              break;
          } while (true);
        }
        if (_jspx_th_spring_005fbind_005f3.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE) {
          return;
        }
      } catch (Throwable _jspx_exception) {
        while (_jspx_push_body_count_spring_005fbind_005f3[0]-- > 0)
          out = _jspx_page_context.popBody();
        _jspx_th_spring_005fbind_005f3.doCatch(_jspx_exception);
      } finally {
        _jspx_th_spring_005fbind_005f3.doFinally();
        _005fjspx_005ftagPool_005fspring_005fbind_0026_005fpath.reuse(_jspx_th_spring_005fbind_005f3);
      }
      out.write("\r\n");
      out.write("               </td>\r\n");
      out.write("              </tr>\r\n");
      out.write("             </table>\r\n");
      out.write("            </div>\r\n");
      out.write("            <div id=\"History\"  style=\"display:block\" align=\"center\">\r\n");
      out.write("             <table  border=\"\"  class=\"sample\" width=680 cellpadding=\"200\" >\r\n");
      out.write("              <tr >\r\n");
      out.write("               Allergies\r\n");
      out.write("              </tr>\r\n");
      out.write("              <tr>\r\n");
      out.write("               <td >\r\n");
      out.write("                 <input type=\"text\" name=\"selectAllergy\"  id=\"selectAllergy\" value=\"\"/>\r\n");
      out.write("                 <script type=\"text/javascript\">\r\n");
      out.write("                   new Autocomplete('selectAllergy', { serviceUrl:'/appointmentPopUp.htm' },'SPECIALTITY');\r\n");
      out.write("                 </script>\r\n");
      out.write("                 \r\n");
      out.write("               </td>\r\n");
      out.write("\t\t               <td >\r\n");
      out.write("\t\t                \r\n");
      out.write("\t\t                <input type=\"button\"  onClick=\"javascript:fn_addToSelect('allergies','selectAllergy');\" alignment=\"center\" value=\">>\" class=\"bsubmit\" id=\"btnAdd\" width=\"75\" />\r\n");
      out.write("\t\t                </br>\r\n");
      out.write("\t\t                <input type=\"button\"  onClick=\"javascript:fn_deleteAllergy();\" alignment=\"center\" value=\"<<\" class=\"bsubmit\" id=\"btnDel\" width=\"75\" />\r\n");
      out.write("\t\t               </td>                  \r\n");
      out.write("\t\t               <td >\r\n");
      out.write("\t\t\t                ");
      //  spring:bind
      org.springframework.web.servlet.tags.BindTag _jspx_th_spring_005fbind_005f4 = (org.springframework.web.servlet.tags.BindTag) _005fjspx_005ftagPool_005fspring_005fbind_0026_005fpath.get(org.springframework.web.servlet.tags.BindTag.class);
      _jspx_th_spring_005fbind_005f4.setPageContext(_jspx_page_context);
      _jspx_th_spring_005fbind_005f4.setParent(null);
      // /WEB-INF/jsp/pastHistory.jsp(91,19) name = path type = null reqTime = true required = true fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
      _jspx_th_spring_005fbind_005f4.setPath("patientDetails.allergies");
      int[] _jspx_push_body_count_spring_005fbind_005f4 = new int[] { 0 };
      try {
        int _jspx_eval_spring_005fbind_005f4 = _jspx_th_spring_005fbind_005f4.doStartTag();
        if (_jspx_eval_spring_005fbind_005f4 != javax.servlet.jsp.tagext.Tag.SKIP_BODY) {
          org.springframework.web.servlet.support.BindStatus status = null;
          status = (org.springframework.web.servlet.support.BindStatus) _jspx_page_context.findAttribute("status");
          do {
            out.write("\r\n");
            out.write("\t\t\t                 \t<select  name=\"");
            if (_jspx_meth_c_005fout_005f5(_jspx_th_spring_005fbind_005f4, _jspx_page_context, _jspx_push_body_count_spring_005fbind_005f4))
              return;
            out.write("\" id=\"");
            if (_jspx_meth_c_005fout_005f6(_jspx_th_spring_005fbind_005f4, _jspx_page_context, _jspx_push_body_count_spring_005fbind_005f4))
              return;
            out.write("\" style=\"width: 25em;\" size=\"3\" multiple >\r\n");
            out.write("\t\t\t                 \t\t");
            if (_jspx_meth_c_005fforEach_005f0(_jspx_th_spring_005fbind_005f4, _jspx_page_context, _jspx_push_body_count_spring_005fbind_005f4))
              return;
            out.write("  \r\n");
            out.write("\t\t\t                 \t</select>\r\n");
            out.write("\t\t\t                \t");
            int evalDoAfterBody = _jspx_th_spring_005fbind_005f4.doAfterBody();
            status = (org.springframework.web.servlet.support.BindStatus) _jspx_page_context.findAttribute("status");
            if (evalDoAfterBody != javax.servlet.jsp.tagext.BodyTag.EVAL_BODY_AGAIN)
              break;
          } while (true);
        }
        if (_jspx_th_spring_005fbind_005f4.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE) {
          return;
        }
      } catch (Throwable _jspx_exception) {
        while (_jspx_push_body_count_spring_005fbind_005f4[0]-- > 0)
          out = _jspx_page_context.popBody();
        _jspx_th_spring_005fbind_005f4.doCatch(_jspx_exception);
      } finally {
        _jspx_th_spring_005fbind_005f4.doFinally();
        _005fjspx_005ftagPool_005fspring_005fbind_0026_005fpath.reuse(_jspx_th_spring_005fbind_005f4);
      }
      out.write("\r\n");
      out.write("\t\t               </td>\r\n");
      out.write("              </tr>\r\n");
      out.write("\t\t\t\t\t");
  
					if(p.getPackages().contains("Patient")){
							
					
      out.write("\r\n");
      out.write("              \r\n");
      out.write("              <tr>\r\n");
      out.write("              <tr>\r\n");
      out.write("              </tr>\r\n");
      out.write("              \t<td> Treatment History :\r\n");
      out.write("              \t</td>\r\n");
      out.write("              \t<td> \r\n");
      out.write("              \t\t<a href=\"javascript:void(0);\" onClick=\"javascript:generateHistory(");
      out.print(p.getIdPerson() );
      out.write(");\" >\r\n");
      out.write("              \t\t\tView \r\n");
      out.write("\t\t\t\t\t</a>\r\n");
      out.write("              \t</td>\r\n");
      out.write("              </tr>\r\n");
      out.write("              ");
}
      out.write("\r\n");
      out.write("              <tr>\r\n");
      out.write("              </tr>\r\n");
      out.write("              \t\t\r\n");
      out.write("             </table>\r\n");
      out.write("              <table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"200\" height=\"30\"  align=\"bottom\">       \r\n");
      out.write("\t\t\t\t\t<tr>     \r\n");
      out.write("\t\t\t\t\t\t<td  style=\"background: url(/images/submitbutton_0.png) no-repeat;overflow: hidden;background-position: top center;height:100%;\"  align=\"center\">  \r\n");
      out.write("\t\t\t\t  \t\t\t<a href=\"javascript:void(0);\" onClick=\"javascript:fn_saveHistory();\" style=\"text-decoration:none\"> \r\n");
      out.write("\t\t\t\t  \t\t\t\t<font size=\"+1\" color=\"#FFFFFF\" >Save</font> \r\n");
      out.write("\t\t\t\t  \t\t\t</a>\r\n");
      out.write("\t\t\t\t  \t\t</td>\r\n");
      out.write("\t\t\t\t\t</tr>\r\n");
      out.write("\t\t\t\t</table>\r\n");
      out.write("            </div>\r\n");
      out.write("            \r\n");
      out.write("            <div id=\"History\"  style=\"display:block\" align=\"right\" >\r\n");
      out.write("              <table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100\" height=\"30\"  align=\"right\">       \r\n");
      out.write("\t\t\t\t\t<tr>     \r\n");
      out.write("\t\t\t\t\t\t<td  style=\"background: url(/images/submitbutton_0.png) no-repeat;overflow: hidden;background-position: top center;height:100%;\"  align=\"center\">  \r\n");
      out.write("\t\t\t\t  \t\t\t<a href=\"javascript:void(0);\" onClick=\"javascript:fn_uploadFile();\" style=\"text-decoration:none\"> \r\n");
      out.write("\t\t\t\t  \t\t\t\t<font size=\"+1\" color=\"#FFFFFF\" >Upload</font> \r\n");
      out.write("\t\t\t\t  \t\t\t</a>\r\n");
      out.write("\t\t\t\t  \t\t</td>\r\n");
      out.write("\t\t\t\t\t</tr>\r\n");
      out.write("\t\t\t\t</table><br></br>\r\n");
      out.write("            \r\n");
      out.write("             <table  border=\"\"  class=\"sample\" width=680 cellpadding=\"200\">\r\n");
      out.write("\t\t\t\t\t<tr>\r\n");
      out.write("\t\t\t\t\t\t<td>\r\n");
      out.write("\t\t\t\t\t\t</td>\t\t\t\t\t\t\r\n");
      out.write("\t\t\t\t\t\t<td width=\"30%\">File Name:\r\n");
      out.write("\t\t\t\t\t\t</td>\r\n");
      out.write("\t\t\t\t\t\t<td width=\"70%\">Comments:\r\n");
      out.write("\t\t\t\t\t\t</td>\r\n");
      out.write("\t\t\t\t\t</tr>\r\n");
      out.write("\t\t\t\t\t");
      //  c:forEach
      org.apache.taglibs.standard.tag.rt.core.ForEachTag _jspx_th_c_005fforEach_005f1 = (org.apache.taglibs.standard.tag.rt.core.ForEachTag) _005fjspx_005ftagPool_005fc_005fforEach_0026_005fvarStatus_005fitems.get(org.apache.taglibs.standard.tag.rt.core.ForEachTag.class);
      _jspx_th_c_005fforEach_005f1.setPageContext(_jspx_page_context);
      _jspx_th_c_005fforEach_005f1.setParent(null);
      // /WEB-INF/jsp/pastHistory.jsp(152,5) name = items type = java.lang.Object reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
      _jspx_th_c_005fforEach_005f1.setItems((java.lang.Object) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${patientDetails.uploadedFiles}", java.lang.Object.class, (PageContext)_jspx_page_context, null, false));
      // /WEB-INF/jsp/pastHistory.jsp(152,5) name = varStatus type = java.lang.String reqTime = false required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
      _jspx_th_c_005fforEach_005f1.setVarStatus("uploadedFiles");
      int[] _jspx_push_body_count_c_005fforEach_005f1 = new int[] { 0 };
      try {
        int _jspx_eval_c_005fforEach_005f1 = _jspx_th_c_005fforEach_005f1.doStartTag();
        if (_jspx_eval_c_005fforEach_005f1 != javax.servlet.jsp.tagext.Tag.SKIP_BODY) {
          do {
            out.write("\r\n");
            out.write("\t\t\t\t\t\t<tr>\r\n");
            out.write("\t\t\t\t\t\t\t<td>\r\n");
            out.write("\t\t\t\t\t\t\t</td>\t\t\t\t\t\t\r\n");
            out.write("\t\t\t\t\t\t\r\n");
            out.write("\t\t\t\t\t\t\t<td>\r\n");
            out.write("\t\t\t\t\t\t\t\t");
            //  spring:bind
            org.springframework.web.servlet.tags.BindTag _jspx_th_spring_005fbind_005f5 = (org.springframework.web.servlet.tags.BindTag) _005fjspx_005ftagPool_005fspring_005fbind_0026_005fpath.get(org.springframework.web.servlet.tags.BindTag.class);
            _jspx_th_spring_005fbind_005f5.setPageContext(_jspx_page_context);
            _jspx_th_spring_005fbind_005f5.setParent((javax.servlet.jsp.tagext.Tag) _jspx_th_c_005fforEach_005f1);
            // /WEB-INF/jsp/pastHistory.jsp(158,8) name = path type = null reqTime = true required = true fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
            _jspx_th_spring_005fbind_005f5.setPath((java.lang.String) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("patientDetails.uploadedFiles[${uploadedFiles.index}].fileName", java.lang.String.class, (PageContext)_jspx_page_context, null, false));
            int[] _jspx_push_body_count_spring_005fbind_005f5 = new int[] { 0 };
            try {
              int _jspx_eval_spring_005fbind_005f5 = _jspx_th_spring_005fbind_005f5.doStartTag();
              if (_jspx_eval_spring_005fbind_005f5 != javax.servlet.jsp.tagext.Tag.SKIP_BODY) {
                org.springframework.web.servlet.support.BindStatus status = null;
                status = (org.springframework.web.servlet.support.BindStatus) _jspx_page_context.findAttribute("status");
                do {
                  out.write("\r\n");
                  out.write("\t\t\t\t\t\t\t\t\t<a href=\"javascript:fn_openFile('");
                  if (_jspx_meth_c_005fout_005f9(_jspx_th_spring_005fbind_005f5, _jspx_page_context, _jspx_push_body_count_spring_005fbind_005f5))
                    return;
                  out.write("')\" >\r\n");
                  out.write("\t\t\t\t\t\t\t\t\t\t");
                  if (_jspx_meth_c_005fout_005f10(_jspx_th_spring_005fbind_005f5, _jspx_page_context, _jspx_push_body_count_spring_005fbind_005f5))
                    return;
                  out.write("\r\n");
                  out.write("\t\t\t\t\t\t\t\t\t</a>\r\n");
                  out.write("\t\t\t\t\t\t\t\t");
                  int evalDoAfterBody = _jspx_th_spring_005fbind_005f5.doAfterBody();
                  status = (org.springframework.web.servlet.support.BindStatus) _jspx_page_context.findAttribute("status");
                  if (evalDoAfterBody != javax.servlet.jsp.tagext.BodyTag.EVAL_BODY_AGAIN)
                    break;
                } while (true);
              }
              if (_jspx_th_spring_005fbind_005f5.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE) {
                return;
              }
            } catch (Throwable _jspx_exception) {
              while (_jspx_push_body_count_spring_005fbind_005f5[0]-- > 0)
                out = _jspx_page_context.popBody();
              _jspx_th_spring_005fbind_005f5.doCatch(_jspx_exception);
            } finally {
              _jspx_th_spring_005fbind_005f5.doFinally();
              _005fjspx_005ftagPool_005fspring_005fbind_0026_005fpath.reuse(_jspx_th_spring_005fbind_005f5);
            }
            out.write("\r\n");
            out.write("\t\t\t\t\t\t\t</td>\r\n");
            out.write("\t\t\t\t\t\t\t<td>\r\n");
            out.write("\t\t\t\t\t\t\t\t");
            //  spring:bind
            org.springframework.web.servlet.tags.BindTag _jspx_th_spring_005fbind_005f6 = (org.springframework.web.servlet.tags.BindTag) _005fjspx_005ftagPool_005fspring_005fbind_0026_005fpath.get(org.springframework.web.servlet.tags.BindTag.class);
            _jspx_th_spring_005fbind_005f6.setPageContext(_jspx_page_context);
            _jspx_th_spring_005fbind_005f6.setParent((javax.servlet.jsp.tagext.Tag) _jspx_th_c_005fforEach_005f1);
            // /WEB-INF/jsp/pastHistory.jsp(165,8) name = path type = null reqTime = true required = true fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
            _jspx_th_spring_005fbind_005f6.setPath((java.lang.String) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("patientDetails.uploadedFiles[${uploadedFiles.index}].comments", java.lang.String.class, (PageContext)_jspx_page_context, null, false));
            int[] _jspx_push_body_count_spring_005fbind_005f6 = new int[] { 0 };
            try {
              int _jspx_eval_spring_005fbind_005f6 = _jspx_th_spring_005fbind_005f6.doStartTag();
              if (_jspx_eval_spring_005fbind_005f6 != javax.servlet.jsp.tagext.Tag.SKIP_BODY) {
                org.springframework.web.servlet.support.BindStatus status = null;
                status = (org.springframework.web.servlet.support.BindStatus) _jspx_page_context.findAttribute("status");
                do {
                  out.write("\r\n");
                  out.write("\t\t\t\t\t\t\t\t\r\n");
                  out.write("\t\t\t\t\t\t\t\t\t");
                  if (_jspx_meth_c_005fout_005f11(_jspx_th_spring_005fbind_005f6, _jspx_page_context, _jspx_push_body_count_spring_005fbind_005f6))
                    return;
                  out.write("\t\t\t\t\t\t\t\t\t\t\t\t\t\r\n");
                  out.write("\t\t\t\t\t\t\t\t");
                  int evalDoAfterBody = _jspx_th_spring_005fbind_005f6.doAfterBody();
                  status = (org.springframework.web.servlet.support.BindStatus) _jspx_page_context.findAttribute("status");
                  if (evalDoAfterBody != javax.servlet.jsp.tagext.BodyTag.EVAL_BODY_AGAIN)
                    break;
                } while (true);
              }
              if (_jspx_th_spring_005fbind_005f6.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE) {
                return;
              }
            } catch (Throwable _jspx_exception) {
              while (_jspx_push_body_count_spring_005fbind_005f6[0]-- > 0)
                out = _jspx_page_context.popBody();
              _jspx_th_spring_005fbind_005f6.doCatch(_jspx_exception);
            } finally {
              _jspx_th_spring_005fbind_005f6.doFinally();
              _005fjspx_005ftagPool_005fspring_005fbind_0026_005fpath.reuse(_jspx_th_spring_005fbind_005f6);
            }
            out.write("\t\t\t\t\t\t\t\t\r\n");
            out.write("\t\t\t\t\t\t\t</td>\r\n");
            out.write("\t\t\t\t\t\t</tr>\r\n");
            out.write("\t\t\t\t\t");
            int evalDoAfterBody = _jspx_th_c_005fforEach_005f1.doAfterBody();
            if (evalDoAfterBody != javax.servlet.jsp.tagext.BodyTag.EVAL_BODY_AGAIN)
              break;
          } while (true);
        }
        if (_jspx_th_c_005fforEach_005f1.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE) {
          return;
        }
      } catch (Throwable _jspx_exception) {
        while (_jspx_push_body_count_c_005fforEach_005f1[0]-- > 0)
          out = _jspx_page_context.popBody();
        _jspx_th_c_005fforEach_005f1.doCatch(_jspx_exception);
      } finally {
        _jspx_th_c_005fforEach_005f1.doFinally();
        _005fjspx_005ftagPool_005fc_005fforEach_0026_005fvarStatus_005fitems.reuse(_jspx_th_c_005fforEach_005f1);
      }
      out.write("\r\n");
      out.write("             </table>\r\n");
      out.write("            </div>\r\n");
      out.write("           </tr>\r\n");
      out.write("           \r\n");
      out.write("          </table>\r\n");
      out.write("        </form>\r\n");
      out.write(" \r\n");
      out.write("       </div>\r\n");
      out.write("      </div>\r\n");
      out.write("      <div id=\"column\">\r\n");
      out.write("      </div>\r\n");
      out.write("     </div></div></div>\r\n");
      out.write("    </div>\r\n");
      out.write("   </div>\r\n");
      out.write("  </div>\r\n");
      out.write("  \r\n");
      out.write("\t\t<div id=\"contentFootLeft\">\r\n");
      out.write("\t\t\t<div id=\"contentFootRight\">\r\n");
      out.write("\t\t\t\t<div id=\"contentFootCenter\"/>\r\n");
      out.write("\t\t\t</div>\r\n");
      out.write("\t\t</div>\r\n");
      out.write("\t\t<div id=\"footer\">\r\n");
      out.write("\t\t\t<p id=\"copyright\"></p>\r\n");
      out.write("\t\t\t<p id=\"info\">\r\n");
      out.write("\t\t\t\tBeta 1.0\r\n");
      out.write("\t\t\t</p>\r\n");
      out.write("\t\t</div>\r\n");
      out.write("\t</div>\r\n");
      out.write("    <script type=\"text/javascript\" src=\"");
      out.print(request.getContextPath());
      out.write("/js/mediapp.js\"></script>\r\n");
      out.write("<!-- Attach events to Link -->\r\n");
      out.write("<div id=\"helpbox\"></div>\r\n");
      out.write("\r\n");
      out.write("</body>\r\n");
      out.write("\r\n");
      out.write("</html>\r\n");
      out.write(' ');
      out.write(' ');
    } catch (Throwable t) {
      if (!(t instanceof SkipPageException)){
        out = _jspx_out;
        if (out != null && out.getBufferSize() != 0)
          try { out.clearBuffer(); } catch (java.io.IOException e) {}
        if (_jspx_page_context != null) _jspx_page_context.handlePageException(t);
      }
    } finally {
      _jspxFactory.releasePageContext(_jspx_page_context);
    }
  }

  private boolean _jspx_meth_menu_005fverticalMenuItemTag_005f0(PageContext _jspx_page_context)
          throws Throwable {
    PageContext pageContext = _jspx_page_context;
    JspWriter out = _jspx_page_context.getOut();
    //  menu:verticalMenuItemTag
    com.mediapp.web.taglibs.VerticalMenuTag _jspx_th_menu_005fverticalMenuItemTag_005f0 = (com.mediapp.web.taglibs.VerticalMenuTag) _005fjspx_005ftagPool_005fmenu_005fverticalMenuItemTag_005fnobody.get(com.mediapp.web.taglibs.VerticalMenuTag.class);
    _jspx_th_menu_005fverticalMenuItemTag_005f0.setPageContext(_jspx_page_context);
    _jspx_th_menu_005fverticalMenuItemTag_005f0.setParent(null);
    int _jspx_eval_menu_005fverticalMenuItemTag_005f0 = _jspx_th_menu_005fverticalMenuItemTag_005f0.doStartTag();
    if (_jspx_th_menu_005fverticalMenuItemTag_005f0.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE) {
      _005fjspx_005ftagPool_005fmenu_005fverticalMenuItemTag_005fnobody.reuse(_jspx_th_menu_005fverticalMenuItemTag_005f0);
      return true;
    }
    _005fjspx_005ftagPool_005fmenu_005fverticalMenuItemTag_005fnobody.reuse(_jspx_th_menu_005fverticalMenuItemTag_005f0);
    return false;
  }

  private boolean _jspx_meth_c_005fout_005f0(javax.servlet.jsp.tagext.JspTag _jspx_th_spring_005fbind_005f0, PageContext _jspx_page_context, int[] _jspx_push_body_count_spring_005fbind_005f0)
          throws Throwable {
    PageContext pageContext = _jspx_page_context;
    JspWriter out = _jspx_page_context.getOut();
    //  c:out
    org.apache.taglibs.standard.tag.rt.core.OutTag _jspx_th_c_005fout_005f0 = (org.apache.taglibs.standard.tag.rt.core.OutTag) _005fjspx_005ftagPool_005fc_005fout_0026_005fvalue_005fnobody.get(org.apache.taglibs.standard.tag.rt.core.OutTag.class);
    _jspx_th_c_005fout_005f0.setPageContext(_jspx_page_context);
    _jspx_th_c_005fout_005f0.setParent((javax.servlet.jsp.tagext.Tag) _jspx_th_spring_005fbind_005f0);
    // /WEB-INF/jsp/pastHistory.jsp(26,63) name = value type = null reqTime = true required = true fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
    _jspx_th_c_005fout_005f0.setValue((java.lang.Object) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${patientDetails.idPatient}", java.lang.Object.class, (PageContext)_jspx_page_context, null, false));
    int _jspx_eval_c_005fout_005f0 = _jspx_th_c_005fout_005f0.doStartTag();
    if (_jspx_th_c_005fout_005f0.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE) {
      _005fjspx_005ftagPool_005fc_005fout_0026_005fvalue_005fnobody.reuse(_jspx_th_c_005fout_005f0);
      return true;
    }
    _005fjspx_005ftagPool_005fc_005fout_0026_005fvalue_005fnobody.reuse(_jspx_th_c_005fout_005f0);
    return false;
  }

  private boolean _jspx_meth_c_005fout_005f1(javax.servlet.jsp.tagext.JspTag _jspx_th_spring_005fbind_005f1, PageContext _jspx_page_context, int[] _jspx_push_body_count_spring_005fbind_005f1)
          throws Throwable {
    PageContext pageContext = _jspx_page_context;
    JspWriter out = _jspx_page_context.getOut();
    //  c:out
    org.apache.taglibs.standard.tag.rt.core.OutTag _jspx_th_c_005fout_005f1 = (org.apache.taglibs.standard.tag.rt.core.OutTag) _005fjspx_005ftagPool_005fc_005fout_0026_005fvalue_005fnobody.get(org.apache.taglibs.standard.tag.rt.core.OutTag.class);
    _jspx_th_c_005fout_005f1.setPageContext(_jspx_page_context);
    _jspx_th_c_005fout_005f1.setParent((javax.servlet.jsp.tagext.Tag) _jspx_th_spring_005fbind_005f1);
    // /WEB-INF/jsp/pastHistory.jsp(32,59) name = value type = null reqTime = true required = true fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
    _jspx_th_c_005fout_005f1.setValue((java.lang.Object) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${patientDetails.weight}", java.lang.Object.class, (PageContext)_jspx_page_context, null, false));
    int _jspx_eval_c_005fout_005f1 = _jspx_th_c_005fout_005f1.doStartTag();
    if (_jspx_th_c_005fout_005f1.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE) {
      _005fjspx_005ftagPool_005fc_005fout_0026_005fvalue_005fnobody.reuse(_jspx_th_c_005fout_005f1);
      return true;
    }
    _005fjspx_005ftagPool_005fc_005fout_0026_005fvalue_005fnobody.reuse(_jspx_th_c_005fout_005f1);
    return false;
  }

  private boolean _jspx_meth_c_005fout_005f2(javax.servlet.jsp.tagext.JspTag _jspx_th_spring_005fbind_005f1, PageContext _jspx_page_context, int[] _jspx_push_body_count_spring_005fbind_005f1)
          throws Throwable {
    PageContext pageContext = _jspx_page_context;
    JspWriter out = _jspx_page_context.getOut();
    //  c:out
    org.apache.taglibs.standard.tag.rt.core.OutTag _jspx_th_c_005fout_005f2 = (org.apache.taglibs.standard.tag.rt.core.OutTag) _005fjspx_005ftagPool_005fc_005fout_0026_005fvalue_005fnobody.get(org.apache.taglibs.standard.tag.rt.core.OutTag.class);
    _jspx_th_c_005fout_005f2.setPageContext(_jspx_page_context);
    _jspx_th_c_005fout_005f2.setParent((javax.servlet.jsp.tagext.Tag) _jspx_th_spring_005fbind_005f1);
    // /WEB-INF/jsp/pastHistory.jsp(34,35) name = value type = null reqTime = true required = true fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
    _jspx_th_c_005fout_005f2.setValue((java.lang.Object) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${status.errorMessage}", java.lang.Object.class, (PageContext)_jspx_page_context, null, false));
    int _jspx_eval_c_005fout_005f2 = _jspx_th_c_005fout_005f2.doStartTag();
    if (_jspx_th_c_005fout_005f2.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE) {
      _005fjspx_005ftagPool_005fc_005fout_0026_005fvalue_005fnobody.reuse(_jspx_th_c_005fout_005f2);
      return true;
    }
    _005fjspx_005ftagPool_005fc_005fout_0026_005fvalue_005fnobody.reuse(_jspx_th_c_005fout_005f2);
    return false;
  }

  private boolean _jspx_meth_c_005fout_005f3(javax.servlet.jsp.tagext.JspTag _jspx_th_spring_005fbind_005f2, PageContext _jspx_page_context, int[] _jspx_push_body_count_spring_005fbind_005f2)
          throws Throwable {
    PageContext pageContext = _jspx_page_context;
    JspWriter out = _jspx_page_context.getOut();
    //  c:out
    org.apache.taglibs.standard.tag.rt.core.OutTag _jspx_th_c_005fout_005f3 = (org.apache.taglibs.standard.tag.rt.core.OutTag) _005fjspx_005ftagPool_005fc_005fout_0026_005fvalue_005fnobody.get(org.apache.taglibs.standard.tag.rt.core.OutTag.class);
    _jspx_th_c_005fout_005f3.setPageContext(_jspx_page_context);
    _jspx_th_c_005fout_005f3.setParent((javax.servlet.jsp.tagext.Tag) _jspx_th_spring_005fbind_005f2);
    // /WEB-INF/jsp/pastHistory.jsp(41,59) name = value type = null reqTime = true required = true fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
    _jspx_th_c_005fout_005f3.setValue((java.lang.Object) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${patientDetails.height}", java.lang.Object.class, (PageContext)_jspx_page_context, null, false));
    int _jspx_eval_c_005fout_005f3 = _jspx_th_c_005fout_005f3.doStartTag();
    if (_jspx_th_c_005fout_005f3.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE) {
      _005fjspx_005ftagPool_005fc_005fout_0026_005fvalue_005fnobody.reuse(_jspx_th_c_005fout_005f3);
      return true;
    }
    _005fjspx_005ftagPool_005fc_005fout_0026_005fvalue_005fnobody.reuse(_jspx_th_c_005fout_005f3);
    return false;
  }

  private boolean _jspx_meth_c_005fout_005f4(javax.servlet.jsp.tagext.JspTag _jspx_th_spring_005fbind_005f2, PageContext _jspx_page_context, int[] _jspx_push_body_count_spring_005fbind_005f2)
          throws Throwable {
    PageContext pageContext = _jspx_page_context;
    JspWriter out = _jspx_page_context.getOut();
    //  c:out
    org.apache.taglibs.standard.tag.rt.core.OutTag _jspx_th_c_005fout_005f4 = (org.apache.taglibs.standard.tag.rt.core.OutTag) _005fjspx_005ftagPool_005fc_005fout_0026_005fvalue_005fnobody.get(org.apache.taglibs.standard.tag.rt.core.OutTag.class);
    _jspx_th_c_005fout_005f4.setPageContext(_jspx_page_context);
    _jspx_th_c_005fout_005f4.setParent((javax.servlet.jsp.tagext.Tag) _jspx_th_spring_005fbind_005f2);
    // /WEB-INF/jsp/pastHistory.jsp(43,35) name = value type = null reqTime = true required = true fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
    _jspx_th_c_005fout_005f4.setValue((java.lang.Object) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${status.errorMessage}", java.lang.Object.class, (PageContext)_jspx_page_context, null, false));
    int _jspx_eval_c_005fout_005f4 = _jspx_th_c_005fout_005f4.doStartTag();
    if (_jspx_th_c_005fout_005f4.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE) {
      _005fjspx_005ftagPool_005fc_005fout_0026_005fvalue_005fnobody.reuse(_jspx_th_c_005fout_005f4);
      return true;
    }
    _005fjspx_005ftagPool_005fc_005fout_0026_005fvalue_005fnobody.reuse(_jspx_th_c_005fout_005f4);
    return false;
  }

  private boolean _jspx_meth_c_005fout_005f5(javax.servlet.jsp.tagext.JspTag _jspx_th_spring_005fbind_005f4, PageContext _jspx_page_context, int[] _jspx_push_body_count_spring_005fbind_005f4)
          throws Throwable {
    PageContext pageContext = _jspx_page_context;
    JspWriter out = _jspx_page_context.getOut();
    //  c:out
    org.apache.taglibs.standard.tag.rt.core.OutTag _jspx_th_c_005fout_005f5 = (org.apache.taglibs.standard.tag.rt.core.OutTag) _005fjspx_005ftagPool_005fc_005fout_0026_005fvalue_005fnobody.get(org.apache.taglibs.standard.tag.rt.core.OutTag.class);
    _jspx_th_c_005fout_005f5.setPageContext(_jspx_page_context);
    _jspx_th_c_005fout_005f5.setParent((javax.servlet.jsp.tagext.Tag) _jspx_th_spring_005fbind_005f4);
    // /WEB-INF/jsp/pastHistory.jsp(92,36) name = value type = null reqTime = true required = true fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
    _jspx_th_c_005fout_005f5.setValue((java.lang.Object) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${status.expression}", java.lang.Object.class, (PageContext)_jspx_page_context, null, false));
    int _jspx_eval_c_005fout_005f5 = _jspx_th_c_005fout_005f5.doStartTag();
    if (_jspx_th_c_005fout_005f5.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE) {
      _005fjspx_005ftagPool_005fc_005fout_0026_005fvalue_005fnobody.reuse(_jspx_th_c_005fout_005f5);
      return true;
    }
    _005fjspx_005ftagPool_005fc_005fout_0026_005fvalue_005fnobody.reuse(_jspx_th_c_005fout_005f5);
    return false;
  }

  private boolean _jspx_meth_c_005fout_005f6(javax.servlet.jsp.tagext.JspTag _jspx_th_spring_005fbind_005f4, PageContext _jspx_page_context, int[] _jspx_push_body_count_spring_005fbind_005f4)
          throws Throwable {
    PageContext pageContext = _jspx_page_context;
    JspWriter out = _jspx_page_context.getOut();
    //  c:out
    org.apache.taglibs.standard.tag.rt.core.OutTag _jspx_th_c_005fout_005f6 = (org.apache.taglibs.standard.tag.rt.core.OutTag) _005fjspx_005ftagPool_005fc_005fout_0026_005fvalue_005fnobody.get(org.apache.taglibs.standard.tag.rt.core.OutTag.class);
    _jspx_th_c_005fout_005f6.setPageContext(_jspx_page_context);
    _jspx_th_c_005fout_005f6.setParent((javax.servlet.jsp.tagext.Tag) _jspx_th_spring_005fbind_005f4);
    // /WEB-INF/jsp/pastHistory.jsp(92,79) name = value type = null reqTime = true required = true fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
    _jspx_th_c_005fout_005f6.setValue((java.lang.Object) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${status.expression}", java.lang.Object.class, (PageContext)_jspx_page_context, null, false));
    int _jspx_eval_c_005fout_005f6 = _jspx_th_c_005fout_005f6.doStartTag();
    if (_jspx_th_c_005fout_005f6.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE) {
      _005fjspx_005ftagPool_005fc_005fout_0026_005fvalue_005fnobody.reuse(_jspx_th_c_005fout_005f6);
      return true;
    }
    _005fjspx_005ftagPool_005fc_005fout_0026_005fvalue_005fnobody.reuse(_jspx_th_c_005fout_005f6);
    return false;
  }

  private boolean _jspx_meth_c_005fforEach_005f0(javax.servlet.jsp.tagext.JspTag _jspx_th_spring_005fbind_005f4, PageContext _jspx_page_context, int[] _jspx_push_body_count_spring_005fbind_005f4)
          throws Throwable {
    PageContext pageContext = _jspx_page_context;
    JspWriter out = _jspx_page_context.getOut();
    //  c:forEach
    org.apache.taglibs.standard.tag.rt.core.ForEachTag _jspx_th_c_005fforEach_005f0 = (org.apache.taglibs.standard.tag.rt.core.ForEachTag) _005fjspx_005ftagPool_005fc_005fforEach_0026_005fvarStatus_005fitems.get(org.apache.taglibs.standard.tag.rt.core.ForEachTag.class);
    _jspx_th_c_005fforEach_005f0.setPageContext(_jspx_page_context);
    _jspx_th_c_005fforEach_005f0.setParent((javax.servlet.jsp.tagext.Tag) _jspx_th_spring_005fbind_005f4);
    // /WEB-INF/jsp/pastHistory.jsp(93,22) name = items type = java.lang.Object reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
    _jspx_th_c_005fforEach_005f0.setItems((java.lang.Object) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${patientDetails.allergies}", java.lang.Object.class, (PageContext)_jspx_page_context, null, false));
    // /WEB-INF/jsp/pastHistory.jsp(93,22) name = varStatus type = java.lang.String reqTime = false required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
    _jspx_th_c_005fforEach_005f0.setVarStatus("legg");
    int[] _jspx_push_body_count_c_005fforEach_005f0 = new int[] { 0 };
    try {
      int _jspx_eval_c_005fforEach_005f0 = _jspx_th_c_005fforEach_005f0.doStartTag();
      if (_jspx_eval_c_005fforEach_005f0 != javax.servlet.jsp.tagext.Tag.SKIP_BODY) {
        do {
          out.write("\r\n");
          out.write("\t\t\t                   \t\t\t<option value =\"");
          if (_jspx_meth_c_005fout_005f7(_jspx_th_c_005fforEach_005f0, _jspx_page_context, _jspx_push_body_count_c_005fforEach_005f0))
            return true;
          out.write('"');
          out.write('>');
          if (_jspx_meth_c_005fout_005f8(_jspx_th_c_005fforEach_005f0, _jspx_page_context, _jspx_push_body_count_c_005fforEach_005f0))
            return true;
          out.write("</option>\r\n");
          out.write("\t\t\t                   \t\t");
          int evalDoAfterBody = _jspx_th_c_005fforEach_005f0.doAfterBody();
          if (evalDoAfterBody != javax.servlet.jsp.tagext.BodyTag.EVAL_BODY_AGAIN)
            break;
        } while (true);
      }
      if (_jspx_th_c_005fforEach_005f0.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE) {
        return true;
      }
    } catch (Throwable _jspx_exception) {
      while (_jspx_push_body_count_c_005fforEach_005f0[0]-- > 0)
        out = _jspx_page_context.popBody();
      _jspx_th_c_005fforEach_005f0.doCatch(_jspx_exception);
    } finally {
      _jspx_th_c_005fforEach_005f0.doFinally();
      _005fjspx_005ftagPool_005fc_005fforEach_0026_005fvarStatus_005fitems.reuse(_jspx_th_c_005fforEach_005f0);
    }
    return false;
  }

  private boolean _jspx_meth_c_005fout_005f7(javax.servlet.jsp.tagext.JspTag _jspx_th_c_005fforEach_005f0, PageContext _jspx_page_context, int[] _jspx_push_body_count_c_005fforEach_005f0)
          throws Throwable {
    PageContext pageContext = _jspx_page_context;
    JspWriter out = _jspx_page_context.getOut();
    //  c:out
    org.apache.taglibs.standard.tag.rt.core.OutTag _jspx_th_c_005fout_005f7 = (org.apache.taglibs.standard.tag.rt.core.OutTag) _005fjspx_005ftagPool_005fc_005fout_0026_005fvalue_005fnobody.get(org.apache.taglibs.standard.tag.rt.core.OutTag.class);
    _jspx_th_c_005fout_005f7.setPageContext(_jspx_page_context);
    _jspx_th_c_005fout_005f7.setParent((javax.servlet.jsp.tagext.Tag) _jspx_th_c_005fforEach_005f0);
    // /WEB-INF/jsp/pastHistory.jsp(94,41) name = value type = null reqTime = true required = true fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
    _jspx_th_c_005fout_005f7.setValue((java.lang.Object) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${patientDetails.allergies[legg.index]}", java.lang.Object.class, (PageContext)_jspx_page_context, null, false));
    int _jspx_eval_c_005fout_005f7 = _jspx_th_c_005fout_005f7.doStartTag();
    if (_jspx_th_c_005fout_005f7.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE) {
      _005fjspx_005ftagPool_005fc_005fout_0026_005fvalue_005fnobody.reuse(_jspx_th_c_005fout_005f7);
      return true;
    }
    _005fjspx_005ftagPool_005fc_005fout_0026_005fvalue_005fnobody.reuse(_jspx_th_c_005fout_005f7);
    return false;
  }

  private boolean _jspx_meth_c_005fout_005f8(javax.servlet.jsp.tagext.JspTag _jspx_th_c_005fforEach_005f0, PageContext _jspx_page_context, int[] _jspx_push_body_count_c_005fforEach_005f0)
          throws Throwable {
    PageContext pageContext = _jspx_page_context;
    JspWriter out = _jspx_page_context.getOut();
    //  c:out
    org.apache.taglibs.standard.tag.rt.core.OutTag _jspx_th_c_005fout_005f8 = (org.apache.taglibs.standard.tag.rt.core.OutTag) _005fjspx_005ftagPool_005fc_005fout_0026_005fvalue_005fnobody.get(org.apache.taglibs.standard.tag.rt.core.OutTag.class);
    _jspx_th_c_005fout_005f8.setPageContext(_jspx_page_context);
    _jspx_th_c_005fout_005f8.setParent((javax.servlet.jsp.tagext.Tag) _jspx_th_c_005fforEach_005f0);
    // /WEB-INF/jsp/pastHistory.jsp(94,99) name = value type = null reqTime = true required = true fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
    _jspx_th_c_005fout_005f8.setValue((java.lang.Object) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${patientDetails.allergies[legg.index]}", java.lang.Object.class, (PageContext)_jspx_page_context, null, false));
    int _jspx_eval_c_005fout_005f8 = _jspx_th_c_005fout_005f8.doStartTag();
    if (_jspx_th_c_005fout_005f8.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE) {
      _005fjspx_005ftagPool_005fc_005fout_0026_005fvalue_005fnobody.reuse(_jspx_th_c_005fout_005f8);
      return true;
    }
    _005fjspx_005ftagPool_005fc_005fout_0026_005fvalue_005fnobody.reuse(_jspx_th_c_005fout_005f8);
    return false;
  }

  private boolean _jspx_meth_c_005fout_005f9(javax.servlet.jsp.tagext.JspTag _jspx_th_spring_005fbind_005f5, PageContext _jspx_page_context, int[] _jspx_push_body_count_spring_005fbind_005f5)
          throws Throwable {
    PageContext pageContext = _jspx_page_context;
    JspWriter out = _jspx_page_context.getOut();
    //  c:out
    org.apache.taglibs.standard.tag.rt.core.OutTag _jspx_th_c_005fout_005f9 = (org.apache.taglibs.standard.tag.rt.core.OutTag) _005fjspx_005ftagPool_005fc_005fout_0026_005fvalue_005fnobody.get(org.apache.taglibs.standard.tag.rt.core.OutTag.class);
    _jspx_th_c_005fout_005f9.setPageContext(_jspx_page_context);
    _jspx_th_c_005fout_005f9.setParent((javax.servlet.jsp.tagext.Tag) _jspx_th_spring_005fbind_005f5);
    // /WEB-INF/jsp/pastHistory.jsp(159,42) name = value type = null reqTime = true required = true fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
    _jspx_th_c_005fout_005f9.setValue((java.lang.Object) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${patientDetails.uploadedFiles[uploadedFiles.index].filePath}", java.lang.Object.class, (PageContext)_jspx_page_context, null, false));
    int _jspx_eval_c_005fout_005f9 = _jspx_th_c_005fout_005f9.doStartTag();
    if (_jspx_th_c_005fout_005f9.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE) {
      _005fjspx_005ftagPool_005fc_005fout_0026_005fvalue_005fnobody.reuse(_jspx_th_c_005fout_005f9);
      return true;
    }
    _005fjspx_005ftagPool_005fc_005fout_0026_005fvalue_005fnobody.reuse(_jspx_th_c_005fout_005f9);
    return false;
  }

  private boolean _jspx_meth_c_005fout_005f10(javax.servlet.jsp.tagext.JspTag _jspx_th_spring_005fbind_005f5, PageContext _jspx_page_context, int[] _jspx_push_body_count_spring_005fbind_005f5)
          throws Throwable {
    PageContext pageContext = _jspx_page_context;
    JspWriter out = _jspx_page_context.getOut();
    //  c:out
    org.apache.taglibs.standard.tag.rt.core.OutTag _jspx_th_c_005fout_005f10 = (org.apache.taglibs.standard.tag.rt.core.OutTag) _005fjspx_005ftagPool_005fc_005fout_0026_005fvalue_005fnobody.get(org.apache.taglibs.standard.tag.rt.core.OutTag.class);
    _jspx_th_c_005fout_005f10.setPageContext(_jspx_page_context);
    _jspx_th_c_005fout_005f10.setParent((javax.servlet.jsp.tagext.Tag) _jspx_th_spring_005fbind_005f5);
    // /WEB-INF/jsp/pastHistory.jsp(160,10) name = value type = null reqTime = true required = true fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
    _jspx_th_c_005fout_005f10.setValue((java.lang.Object) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${patientDetails.uploadedFiles[uploadedFiles.index].fileName}", java.lang.Object.class, (PageContext)_jspx_page_context, null, false));
    int _jspx_eval_c_005fout_005f10 = _jspx_th_c_005fout_005f10.doStartTag();
    if (_jspx_th_c_005fout_005f10.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE) {
      _005fjspx_005ftagPool_005fc_005fout_0026_005fvalue_005fnobody.reuse(_jspx_th_c_005fout_005f10);
      return true;
    }
    _005fjspx_005ftagPool_005fc_005fout_0026_005fvalue_005fnobody.reuse(_jspx_th_c_005fout_005f10);
    return false;
  }

  private boolean _jspx_meth_c_005fout_005f11(javax.servlet.jsp.tagext.JspTag _jspx_th_spring_005fbind_005f6, PageContext _jspx_page_context, int[] _jspx_push_body_count_spring_005fbind_005f6)
          throws Throwable {
    PageContext pageContext = _jspx_page_context;
    JspWriter out = _jspx_page_context.getOut();
    //  c:out
    org.apache.taglibs.standard.tag.rt.core.OutTag _jspx_th_c_005fout_005f11 = (org.apache.taglibs.standard.tag.rt.core.OutTag) _005fjspx_005ftagPool_005fc_005fout_0026_005fvalue_005fnobody.get(org.apache.taglibs.standard.tag.rt.core.OutTag.class);
    _jspx_th_c_005fout_005f11.setPageContext(_jspx_page_context);
    _jspx_th_c_005fout_005f11.setParent((javax.servlet.jsp.tagext.Tag) _jspx_th_spring_005fbind_005f6);
    // /WEB-INF/jsp/pastHistory.jsp(167,9) name = value type = null reqTime = true required = true fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
    _jspx_th_c_005fout_005f11.setValue((java.lang.Object) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${fn:trim(patientDetails.uploadedFiles[uploadedFiles.index].comments)}", java.lang.Object.class, (PageContext)_jspx_page_context, _jspx_fnmap_0, false));
    int _jspx_eval_c_005fout_005f11 = _jspx_th_c_005fout_005f11.doStartTag();
    if (_jspx_th_c_005fout_005f11.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE) {
      _005fjspx_005ftagPool_005fc_005fout_0026_005fvalue_005fnobody.reuse(_jspx_th_c_005fout_005f11);
      return true;
    }
    _005fjspx_005ftagPool_005fc_005fout_0026_005fvalue_005fnobody.reuse(_jspx_th_c_005fout_005f11);
    return false;
  }
}
