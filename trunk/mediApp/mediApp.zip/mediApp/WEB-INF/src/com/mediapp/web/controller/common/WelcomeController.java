/**
 * 
 */
package com.mediapp.web.controller.common;

public class WelcomeController extends MediAppBaseController {
}
